#!/usr/bin/env python3
"""
goal_marker.py — มาร์กจุดให้รถไป (ใช้กับแพ็กเกจ tes / Nav2)

ทำอะไรได้:
  mark <ชื่อ>                 บันทึกตำแหน่ง+ทิศปัจจุบันของรถ (map -> rear_axle_link) เป็นจุดชื่อนี้
  markxy <ชื่อ> <x> <y> [yaw_deg]   บันทึกจุดด้วยการพิมพ์พิกัดเอง
  go <ชื่อ>                   ส่ง NavigateToPose ให้รถไปที่จุดนั้น
  cancel                      ยกเลิกเป้าหมายที่กำลังไป
  list                        แสดงจุดทั้งหมด
  del <ชื่อ>                  ลบจุด
  quit                        ออก

จุดถูกเก็บในไฟล์ YAML (default ~/ros2_ws/src/tes/config/marked_points.yaml)
และแสดงเป็น marker ใน RViz ที่ topic /marked_points (เพิ่ม MarkerArray display)

หมายเหตุสำคัญ: ถ้าจะให้จุดที่มาร์กไว้ใช้ได้ข้ามรอบการเปิดเครื่อง ต้องรันแบบ
localization (car1_core_localization.launch.py + แผนที่ที่ save ไว้) เพราะโหมด SLAM
จะตั้ง map origin ใหม่ทุกครั้งที่เปิด จุดเดิมจะไม่ตรงที่เดิม

รัน:
  ros2 run tes goal_marker.py
  # หรือ
  python3 goal_marker.py --ros-args -p base_frame:=rear_axle_link
"""
import math
import os
import threading

import yaml
import rclpy
import tf2_ros
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy
from rclpy.time import Time
from rclpy.duration import Duration
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose
from visualization_msgs.msg import Marker, MarkerArray


def yaw_from_quat(q):
    siny = 2.0 * (q.w * q.z + q.x * q.y)
    cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny, cosy)


def quat_from_yaw(yaw):
    return math.sin(yaw / 2.0), math.cos(yaw / 2.0)  # (z, w)


class GoalMarker(Node):
    def __init__(self):
        super().__init__('goal_marker')

        default_file = os.path.expanduser(
            '~/ros2_ws/src/tes/config/marked_points.yaml')
        self.declare_parameter('points_file', default_file)
        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('base_frame', 'rear_axle_link')
        self.declare_parameter('action_name', 'navigate_to_pose')

        self.points_file = self.get_parameter('points_file').value
        self.map_frame = self.get_parameter('map_frame').value
        self.base_frame = self.get_parameter('base_frame').value

        self.points = {}   # name -> {'x':..,'y':..,'yaw':..}
        self._load()

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.nav_client = ActionClient(
            self, NavigateToPose, self.get_parameter('action_name').value)
        self._goal_handle = None

        qos = QoSProfile(depth=1,
                         durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE)
        self.marker_pub = self.create_publisher(MarkerArray, '/marked_points', qos)
        self.create_timer(1.0, self._publish_markers)

    # ---------- เก็บ/โหลดไฟล์ ----------
    def _load(self):
        if os.path.exists(self.points_file):
            with open(self.points_file, 'r') as f:
                self.points = yaml.safe_load(f) or {}
            self.get_logger().info(
                f'โหลด {len(self.points)} จุดจาก {self.points_file}')

    def _save(self):
        os.makedirs(os.path.dirname(self.points_file), exist_ok=True)
        with open(self.points_file, 'w') as f:
            yaml.safe_dump(self.points, f, sort_keys=True)

    # ---------- คำสั่ง ----------
    def mark_current(self, name):
        try:
            t = self.tf_buffer.lookup_transform(
                self.map_frame, self.base_frame, Time(),
                timeout=Duration(seconds=1.0))
        except Exception as e:
            print(f'อ่านตำแหน่งรถไม่ได้ ({self.map_frame}->{self.base_frame}): {e}')
            return
        tr, q = t.transform.translation, t.transform.rotation
        self.points[name] = {'x': round(tr.x, 3), 'y': round(tr.y, 3),
                             'yaw': round(yaw_from_quat(q), 4)}
        self._save()
        self._publish_markers()
        p = self.points[name]
        print(f"มาร์ก '{name}' = x {p['x']}, y {p['y']}, "
              f"yaw {math.degrees(p['yaw']):.1f}°")

    def mark_xy(self, name, x, y, yaw_deg=0.0):
        self.points[name] = {'x': round(x, 3), 'y': round(y, 3),
                             'yaw': round(math.radians(yaw_deg), 4)}
        self._save()
        self._publish_markers()
        print(f"มาร์ก '{name}' = x {x}, y {y}, yaw {yaw_deg}°")

    def go(self, name):
        p = self.points.get(name)
        if p is None:
            print(f"ไม่มีจุดชื่อ '{name}' (พิมพ์ list ดู)")
            return
        if not self.nav_client.wait_for_server(timeout_sec=3.0):
            print('ไม่เจอ action server navigate_to_pose (Nav2 active หรือยัง?)')
            return

        goal = NavigateToPose.Goal()
        ps = PoseStamped()
        ps.header.frame_id = self.map_frame
        ps.header.stamp = self.get_clock().now().to_msg()
        ps.pose.position.x = float(p['x'])
        ps.pose.position.y = float(p['y'])
        ps.pose.orientation.z, ps.pose.orientation.w = quat_from_yaw(p['yaw'])
        goal.pose = ps

        print(f"ส่งรถไปที่ '{name}' ...")
        fut = self.nav_client.send_goal_async(goal)
        fut.add_done_callback(self._goal_response)

    def _goal_response(self, fut):
        gh = fut.result()
        if not gh.accepted:
            print('Nav2 ปฏิเสธเป้าหมาย')
            return
        self._goal_handle = gh
        gh.get_result_async().add_done_callback(self._goal_result)

    def _goal_result(self, fut):
        status = fut.result().status
        names = {4: 'สำเร็จ', 5: 'ถูกยกเลิก', 6: 'ล้มเหลว'}
        print(f'ผลลัพธ์: {names.get(status, status)}')
        self._goal_handle = None

    def cancel(self):
        if self._goal_handle is None:
            print('ไม่มีเป้าหมายที่กำลังไป')
            return
        self._goal_handle.cancel_goal_async()
        print('ส่งคำสั่งยกเลิกแล้ว')

    def delete(self, name):
        if self.points.pop(name, None) is None:
            print(f"ไม่มีจุดชื่อ '{name}'")
            return
        self._save()
        self._publish_markers()
        print(f"ลบ '{name}' แล้ว")

    def list_points(self):
        if not self.points:
            print('(ยังไม่มีจุด)')
        for n, p in sorted(self.points.items()):
            print(f"  {n}: x {p['x']}, y {p['y']}, yaw {math.degrees(p['yaw']):.1f}°")

    # ---------- marker ใน RViz ----------
    def _publish_markers(self):
        arr = MarkerArray()
        clear = Marker()
        clear.action = Marker.DELETEALL
        arr.markers.append(clear)
        for i, (name, p) in enumerate(sorted(self.points.items())):
            z, w = quat_from_yaw(p['yaw'])

            arrow = Marker()
            arrow.header.frame_id = self.map_frame
            arrow.ns, arrow.id = 'point_arrow', i
            arrow.type, arrow.action = Marker.ARROW, Marker.ADD
            arrow.pose.position.x, arrow.pose.position.y = float(p['x']), float(p['y'])
            arrow.pose.orientation.z, arrow.pose.orientation.w = z, w
            arrow.scale.x, arrow.scale.y, arrow.scale.z = 0.35, 0.06, 0.06
            arrow.color.r, arrow.color.g, arrow.color.b, arrow.color.a = 0.1, 0.8, 0.2, 1.0
            arr.markers.append(arrow)

            text = Marker()
            text.header.frame_id = self.map_frame
            text.ns, text.id = 'point_name', i
            text.type, text.action = Marker.TEXT_VIEW_FACING, Marker.ADD
            text.pose.position.x, text.pose.position.y = float(p['x']), float(p['y'])
            text.pose.position.z = 0.25
            text.scale.z = 0.15
            text.color.r = text.color.g = text.color.b = text.color.a = 1.0
            text.text = name
            arr.markers.append(text)
        self.marker_pub.publish(arr)


def main():
    rclpy.init()
    node = GoalMarker()
    threading.Thread(target=rclpy.spin, args=(node,), daemon=True).start()

    print(__doc__.split('จุดถูกเก็บ')[0])
    try:
        while rclpy.ok():
            try:
                parts = input('goal> ').strip().split()
            except EOFError:
                break
            if not parts:
                continue
            cmd, args = parts[0].lower(), parts[1:]
            try:
                if cmd == 'mark' and len(args) == 1:
                    node.mark_current(args[0])
                elif cmd == 'markxy' and len(args) in (3, 4):
                    node.mark_xy(args[0], float(args[1]), float(args[2]),
                                 float(args[3]) if len(args) == 4 else 0.0)
                elif cmd == 'go' and len(args) == 1:
                    node.go(args[0])
                elif cmd == 'cancel':
                    node.cancel()
                elif cmd == 'list':
                    node.list_points()
                elif cmd == 'del' and len(args) == 1:
                    node.delete(args[0])
                elif cmd in ('quit', 'exit', 'q'):
                    break
                else:
                    print('คำสั่งไม่ถูกต้อง: mark | markxy | go | cancel | list | del | quit')
            except ValueError:
                print('ค่าตัวเลขไม่ถูกต้อง')
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
