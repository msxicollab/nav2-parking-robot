#!/usr/bin/env python3
"""
parking_spot_detector.py  (v3 - หาช่องจอด "รูปตัวยู" จากแมพ)

*** เปลี่ยนแนวทางการตรวจจับจาก v2 ***
v2 (เดิม): หาก้อนสิ่งกีดขวางขนาดเท่าเสา (connected component เล็กๆ) แล้วจับคู่
      เสาสองก้อนที่ห่างกันพอดีเป็นช่องจอด -- ก้อนไหนใหญ่/ยาวเกิน
      wall_reject_max_dim_m ถูกทิ้งทันทีเพราะถือว่าเป็นกำแพง ไม่ใช่เสา
      ปัญหา: ช่องจอดจริงหน้างานบางจุดเป็น "ร่องตัวยู" คือมีผนัง/สิ่งกีดขวาง
      ต่อเนื่องปิดล้อม 3 ด้าน (ซ้าย-ขวา-ก้นช่อง) เปิดด้านเดียว (ปากทางเข้า)
      ซึ่งเป็นก้อนใหญ่ก้อนเดียว ไม่ใช่เสาสองต้นแยกกัน -- v2 มองว่าเป็นกำแพง
      แล้วทิ้งทิ้งไปเลย ตรวจไม่เจอ

v3 (ใหม่): เลิกวิเคราะห์ "รูปร่างก้อนสิ่งกีดขวาง" (cluster/connected component)
      ทั้งหมด เปลี่ยนเป็น **เลื่อนกรอบสี่เหลี่ยมทดสอบ (template matching)**
      ไปทั่วพื้นที่รอบตำแหน่งรถแทน ทั้งตำแหน่ง (x, y) และมุมหัน (theta) แล้ว
      เช็คแต่ละกรอบว่าตรงลักษณะ "ช่องจอดรูปตัวยู" หรือไม่ โดยสุ่มเก็บตัวอย่าง
      (probe) ค่า occupancy จากแมพตามตำแหน่งต่างๆ รอบกรอบ:

        ก้นช่อง (back)   -----------------
        ผนังซ้าย (left)  |               |  ผนังขวา (right)
                         |   พื้นที่จอด   |
                         |   (ว่างทั้งหมด) |
                         -----------------
                         ปากช่อง (mouth, เปิด)

      เงื่อนไขที่ต้องผ่านครบถึงจะถือว่าเป็นช่องจอดตัวยู:
        1) พื้นที่ภายในกรอบ (bay_width_m x bay_depth_m)  ต้องว่างเกือบทั้งหมด
        2) แถบผนังซ้าย/ขวา/ก้นช่อง (ห่างออกไป wall_probe_offset_m จากขอบกรอบ)
           ต้องเป็นสิ่งกีดขวางเป็นส่วนใหญ่ (ไม่สนว่าเป็นก้อนเดียวกันหรือคนละ
           ก้อน ไม่สนรูปร่าง/ขนาดก้อนอีกต่อไป)
        3) แถบปากช่อง (ห่างออกไป mouth_probe_offset_m จากขอบกรอบฝั่งเปิด)
           ต้องไม่ใช่สิ่งกีดขวางเป็นส่วนใหญ่ (โล่งพอให้รถเข้าได้)

      ไม่มีขั้นตอน BFS/connected-component หรือ "wall_reject_max_dim_m" อีก
      ต่อไป เพราะไม่ได้สนใจรูปร่างก้อนสิ่งกีดขวางโดยตรง สนใจแค่ "รูปทรงช่องว่าง
      ที่ล้อมด้วยสิ่งกีดขวาง 3 ด้าน" เท่านั้น ทำให้ตรวจได้ทั้งกรณีเสาคู่แยกกัน
      (เดิม v2 ก็จับได้) และกรณีผนัง/สิ่งกีดขวางต่อเนื่องเป็นก้อนเดียวรูปตัวยู
      (เคสนี้ที่ v2 พลาด) โดยใช้อัลกอริทึมเดียวกัน

      ในบรรดากรอบที่ผ่านเกณฑ์ทั้งหมด เลือกกรอบที่ "จุดจอดสุดท้ายอยู่ใกล้รถ
      ที่สุด" เป็นเป้าหมาย เหมือนหลักการเดิมใน v2 (สมมติฐาน: ผู้ขับจอดรถไว้ใกล้
      ช่องที่ต้องการอยู่แล้วก่อนกด B)

      *** การสแกน (x, y, theta) แบบ brute-force นี้กินเวลาประมวลผลมากกว่า v2
      พอสมควร ถ้าแมพ/พื้นที่ค้นหาใหญ่มากควรลด search_radius_m หรือเพิ่ม
      position_step_m / angle_step_deg เพื่อลดจำนวนกรอบที่ต้องเช็ค (ดู
      หมายเหตุเรื่อง performance ด้านล่าง __init__) ***

หลักการ (สรุปเป็นขั้นตอน):
  1) รอ /map (OccupancyGrid) และตำแหน่งรถปัจจุบัน (TF map->base_link)
  2) เลื่อนจุดศูนย์กลางกรอบทดสอบ (cx, cy) ไปทั่ววงกลมรัศมี search_radius_m
     รอบตำแหน่งรถ ทีละ position_step_m เมตร
  3) ที่แต่ละ (cx, cy) หมุนมุมทดสอบ theta ครบ 360 องศา ทีละ angle_step_deg
  4) เช็คเงื่อนไข "ช่องจอดตัวยู" ตามที่อธิบายข้างต้น -- กรอบไหนผ่านครบถือเป็น
     candidate ที่ใช้ได้
  5) เลือก candidate ที่จุดจอดสุดท้ายอยู่ใกล้รถที่สุด เป็นเป้าหมาย
  6) publish เป้าหมาย (อยู่ลึกเข้าไปในช่อง target_depth_ratio ของความลึกช่อง
     กันจุดจอดไปชนก้นช่องพอดีเป๊ะ) + เส้นขอบช่องตัวยูที่เจอ ให้ดูใน RViz

Subscribe:
  /map              (nav_msgs/OccupancyGrid)  QoS transient_local (latched)
                     ตรงกับที่ slam_toolbox/map_server publish
  /parking/active   (std_msgs/Bool)           มาจาก parking_mode_manager.py
  /parking/rescan   (std_msgs/Bool)           ส่ง True มาเพื่อบังคับคำนวณใหม่
                     ทันที (ข้าม recompute_min_interval_sec)
  TF: map -> base_link  (หาตำแหน่งรถปัจจุบัน ใช้เป็นจุดศูนย์กลางการค้นหา และ
                          ใช้เลือกว่า candidate ไหน "ใกล้รถสุด")

Publish:
  /parking/target_pose      (geometry_msgs/PoseStamped)  frame_id = "map"
  /parking/spot_marker      (visualization_msgs/Marker)  cube ตำแหน่งจอดที่เลือก
  /parking/bay_outline_marker (visualization_msgs/Marker) line strip รูปทรง
                              ช่องตัวยูที่เจอ (ปากช่อง+ผนังซ้าย+ก้นช่อง+ผนังขวา)

*** ค่าพารามิเตอร์ทั้งหมดเป็นค่าประมาณเริ่มต้น ต้องปรับตามขนาดช่องจอด/ความหนา
ผนังจริงหน้างาน โดยเฉพาะ bay_width_m และ bay_depth_m ต้องวัดจากช่องจอดตัวยู
จริงที่จะใช้งาน (ระยะภายในโล่งๆ ของช่อง ไม่ใช่ระยะจากขอบนอกถึงขอบนอก) ***
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
)

from std_msgs.msg import Bool
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped, Point
from visualization_msgs.msg import Marker

import tf2_ros
from rclpy.time import Time


def yaw_from_quaternion(q) -> float:
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


def quaternion_from_yaw(yaw: float):
    return (0.0, 0.0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


def normalize_angle(angle: float) -> float:
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


def frange(start: float, stop: float, step: float):
    """range() เวอร์ชันรับ float step (step ต้องเป็นบวก)"""
    n = int(math.floor((stop - start) / step + 1e-9)) + 1
    for i in range(max(n, 0)):
        yield start + i * step


def linspace(a: float, b: float, n: int):
    """คืน n จุดกระจายสม่ำเสมอระหว่าง a..b (รวมปลายทั้งสองข้าง), n >= 1"""
    if n <= 1:
        return [(a + b) / 2.0]
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# จำนวนจุด probe ต่อด้าน (ค่าคงที่ภายใน ไม่ได้เปิดเป็น ROS parameter เพราะ
# ปรับไม่บ่อยเท่าค่าระยะ/สัดส่วน -- ถ้าต้องการความละเอียดขึ้นปรับได้ตรงนี้)
N_INTERIOR_DEPTH = 4
N_INTERIOR_LATERAL = 3
N_WALL_SAMPLES = 5
N_MOUTH_SAMPLES = 5


class ParkingSpotDetector(Node):

    def __init__(self):
        super().__init__('parking_spot_detector')

        # ============================================================
        # PARAMETERS
        # ============================================================
        self.declare_parameter('map_topic', '/map')
        self.declare_parameter('occupied_threshold', 65)   # cell >= นี้ = สิ่งกีดขวาง (0-100)
        self.declare_parameter('free_threshold', 25)       # cell <= นี้ = พื้นที่ว่าง

        # ============================================================
        # *** ขนาดช่องจอดตัวยู -- จุดหลักที่ต้องแก้เวลาเปลี่ยนขนาดช่องจอด ***
        # วัดจากพื้นที่ว่างภายในจริง ไม่ใช่ขอบนอกกำแพง
        # (ค่า default ด้านล่างเป็นค่าเริ่มต้นเท่านั้น หน้างานจริงมักสั่งทับตอนรันด้วย -p)
        #
        # ตัวอย่างคำสั่งรันที่ใช้กับช่องขนาด 0.47 x 0.54 m:
        #   ros2 run tes parking_spot_detector.py --ros-args \
        #     -p bay_width_m:=0.47 -p bay_depth_m:=0.54 \
        #     -p wall_probe_offset_m:=0.05 \
        #     -p position_step_m:=0.05 -p angle_step_deg:=10.0 \
        #     -p interior_free_ratio_min:=0.7 -p wall_fill_ratio_min:=0.4 \
        #     -p search_radius_m:=1.0 -p target_depth_ratio:=0.5
        #
        # CHECKLIST เมื่อเปลี่ยนขนาดช่องจอด (เรียงตามความสำคัญ):
        #  1) bay_width_m / bay_depth_m   -> ต้องวัดใหม่ให้ตรงช่องจริง (บรรทัดล่างนี้)
        #     * กว้าง (width) = ซ้าย-ขวา, ลึก (depth) = จากปากช่องไปก้นช่อง
        #     * width ต้องมากกว่าความกว้างตัวรถ ไม่งั้นรถเข้าไม่ได้
        #  2) wall_probe_offset_m         -> ต้องน้อยกว่า "ครึ่งของด้านที่เล็กที่สุด"
        #     (เช่นช่อง 0.47 กว้าง ครึ่งหนึ่ง = 0.235 ตั้ง 0.05 ได้) ถ้าช่องเล็กลงมากๆ
        #     ให้ลดลงอีก ไม่งั้นจุด probe ภายในช่องจะกลับด้านและเช็คผิดที่
        #  3) spot_marker_length / spot_marker_width (ด้านล่าง) -> แค่ขนาดกรอบเขียวใน
        #     RViz ไม่กระทบการคำนวณ ถ้าอยากให้ตรงช่อง: length = bay_depth_m,
        #     width = bay_width_m
        #  4) target_depth_ratio          -> จุดจอดลึกกี่ % ของความลึกช่อง (0.5 = กลางช่อง)
        #     ช่องลึกขึ้น/ตื้นขึ้นควรเช็คว่ารถทั้งคันยังอยู่ในช่องพอดี
        #  5) search_radius_m             -> ต้องกว้างพอให้ครอบคลุมตำแหน่งช่องจากจุดที่รถจอด
        #  6) position_step_m / angle_step_deg -> ช่องเล็กลงควรลด step ลง (ไม่งั้นกรอบ
        #     หยาบข้ามช่องไปเลย) แต่ยิ่งเล็กยิ่งช้า
        #  7) interior_free_ratio_min / wall_fill_ratio_min -> ถ้าตรวจไม่เจอ ลองลดลง
        #     (ดู log 'DEBUG ตกเงื่อนไข' ว่าตกที่ด่านไหนมากที่สุด)
        #  8) refine_position_range_m / refine_angle_range_deg -> ควรมากกว่าหรือเท่ากับ
        #     position_step_m / angle_step_deg เพื่อให้ครอบคลุมช่วงที่ผ่านทั้งหมด
        #  9) ฝั่ง parking_maneuver.py (อยู่คนละไฟล์) -> ถ้ามีพารามิเตอร์ที่อิงขนาด
        #     ช่อง/ระยะเผื่อ ก็ต้องปรับให้สอดคล้องกันด้วย
        # ============================================================
        self.declare_parameter('bay_width_m', 0.60)    # ความกว้างช่อง (ซ้าย-ขวา) [ปรับตามช่องจริง]
        self.declare_parameter('bay_depth_m', 0.60)    # ความลึกช่อง (ปาก-ก้นช่อง) [ปรับตามช่องจริง]

        # --- ค้นหารอบตำแหน่งรถปัจจุบัน (สมมติฐาน: ผู้ขับจอดใกล้ช่องที่ต้องการ
        #     อยู่แล้วก่อนกด B เหมือน v2) ---
        # [ปรับตามหน้างาน] รัศมีค้นหารอบรถ ต้องครอบคลุมช่องที่ต้องการ
        self.declare_parameter('search_radius_m', 1.5)
        # ระยะห่างระหว่างจุดทดสอบแต่ละจุด (x,y) -- ยิ่งเล็กยิ่งละเอียดแต่ยิ่งช้า
        self.declare_parameter('position_step_m', 0.15)
        # ความละเอียดมุมหัน (องศา) -- ยิ่งเล็กยิ่งละเอียดแต่ยิ่งช้า (สแกนเต็ม 360)
        self.declare_parameter('angle_step_deg', 20.0)

        # --- ระยะ probe ผนัง/ปากช่อง ห่างออกไปจากขอบกรอบเท่าไหร่ (กันกรณี
        #     ผนังจริงหนา/มี inflation จนขอบกรอบพอดีเป๊ะไม่โดนสิ่งกีดขวาง) ---
        # [ผูกกับขนาดช่อง] ต้อง < ครึ่งหนึ่งของ bay_width_m/bay_depth_m ที่เล็กสุด
        self.declare_parameter('wall_probe_offset_m', 0.10)
        self.declare_parameter('mouth_probe_offset_m', 0.15)

        # --- เกณฑ์ผ่าน/ไม่ผ่าน (สัดส่วนจุด probe ที่ต้องตรงเงื่อนไข 0.0-1.0) ---
        self.declare_parameter('interior_free_ratio_min', 0.85)
        self.declare_parameter('wall_fill_ratio_min', 0.6)
        self.declare_parameter('mouth_open_ratio_min', 0.6)

        # --- จุดจอดสุดท้ายอยู่ลึกเข้าไปในช่องกี่เปอร์เซ็นต์ของความลึก
        #     0.0 = ชิดปากช่อง, 1.0 = ชิดก้นช่องพอดี (เสี่ยงชน costmap
        #     inflation รอบก้นช่อง) ค่ากลางๆ ปลอดภัยกว่า ---
        # [ผูกกับขนาดช่อง] ช่องลึก/ตื้นเปลี่ยน -> เช็คว่ารถทั้งคันอยู่ในช่องพอดี
        self.declare_parameter('target_depth_ratio', 0.65)

        # true = เป้าหมายให้รถหันหัวเข้าหาก้นช่อง (จอดหัวชนก้น)
        # false = หันหัวออกฝั่งปากช่อง (ถอยเข้าจอด หันหัวพร้อมขับออกได้เลย)
        # *** ยังไม่ได้ยืนยันจากการทดสอบจริงหน้างาน ลองทั้งสองค่าดูว่าตรงกับที่ต้องการ ***
        self.declare_parameter('face_into_gap', False)

        # --- โหมดจอด: 'perpendicular' = จอดตั้งฉากเข้าช่อง (พฤติกรรมเดิม ใช้ face_into_gap)
        #     'parallel' = จอดเทียบข้าง: กรอบตัวยูเดิมใช้ได้เลย โดยให้
        #       bay_width_m = ความยาวช่องตามแนวถนน/ผนัง, bay_depth_m = ความลึกจากถนนถึงขอบ
        #     แต่รถต้องหันขนานกับแนวถนน (yaw = theta +/- 90deg) ไม่ใช่หันเข้าก้นช่อง ---
        self.declare_parameter('parking_style', 'perpendicular')
        # parallel เท่านั้น: เลือกทิศหัวรถ +1 = theta+90deg, -1 = theta-90deg,
        # 0 = เลือกทิศที่ใกล้ yaw ปัจจุบันของรถที่สุด (auto)
        self.declare_parameter('parallel_heading_sign', 0)
        # parallel เท่านั้น: ระยะจากเพลาหลัง (rear_axle_link) ถึงกึ่งกลางตัวรถตามแนวยาว
        # = (หน้า 0.40 + หลัง -0.085)/2 = 0.1575 ถ้า Nav2 ใช้ rear_axle_link เป็น base frame;
        # ตั้ง 0.0 ถ้าต้องการให้ตำแหน่งเป้าหมายเป็นกึ่งกลางตัวรถ
        self.declare_parameter('parallel_axle_offset_m', 0.1575)

        # ขนาด marker cube แสดงจุดจอดใน RViz เท่านั้น ไม่กระทบการคำนวณ
        # [ผูกกับขนาดช่อง] ถ้าอยากให้กรอบเขียวทับช่องพอดี: length = bay_depth_m,
        # width = bay_width_m (length ตามแนวหน้า-หลังของรถ, width ตามแนวซ้าย-ขวา)
        self.declare_parameter('spot_marker_length', 0.5)   # m
        self.declare_parameter('spot_marker_width', 0.35)   # m

        # กันประมวลผลถี่เกินไปทุกครั้งที่ /map อัปเดต -- v3 คำนวณหนักกว่า v2
        # (สแกน x,y,theta) จึงตั้งค่าเริ่มต้นสูงกว่า v2 ไว้ก่อน
        self.declare_parameter('recompute_min_interval_sec', 2.0)

        # --- ขั้นปรับละเอียด (refine) หลังเจอกรอบหยาบ: สแกนมุม/ตำแหน่งรอบๆ กรอบที่เจอ
        #     ด้วยขั้นเล็กๆ แล้วเอา "จุดกึ่งกลางของกลุ่มกรอบที่ผ่านทั้งหมด" เป็นกรอบสุดท้าย
        #     ทำให้กรอบเขียว/ขอบส้มขนานกับผนังช่องจริง ไม่ติดมุมทีละ angle_step_deg ---
        self.declare_parameter('refine_enabled', True)
        # ควรกว้างอย่างน้อยเท่า angle_step_deg เพื่อให้ครอบคลุมช่วงมุมที่ผ่านทั้งหมด
        self.declare_parameter('refine_angle_range_deg', 30.0)
        self.declare_parameter('refine_angle_step_deg', 1.0)
        self.declare_parameter('refine_position_range_m', 0.15)
        self.declare_parameter('refine_position_step_m', 0.03)

        self.occupied_threshold = int(self.get_parameter('occupied_threshold').value)
        self.free_threshold = int(self.get_parameter('free_threshold').value)
        self.bay_width_m = float(self.get_parameter('bay_width_m').value)
        self.bay_depth_m = float(self.get_parameter('bay_depth_m').value)
        self.search_radius_m = float(self.get_parameter('search_radius_m').value)
        self.position_step_m = float(self.get_parameter('position_step_m').value)
        self.angle_step_deg = float(self.get_parameter('angle_step_deg').value)
        self.wall_probe_offset_m = float(self.get_parameter('wall_probe_offset_m').value)
        self.mouth_probe_offset_m = float(self.get_parameter('mouth_probe_offset_m').value)
        self.interior_free_ratio_min = float(self.get_parameter('interior_free_ratio_min').value)
        self.wall_fill_ratio_min = float(self.get_parameter('wall_fill_ratio_min').value)
        self.mouth_open_ratio_min = float(self.get_parameter('mouth_open_ratio_min').value)
        self.target_depth_ratio = float(self.get_parameter('target_depth_ratio').value)
        self.face_into_gap = bool(self.get_parameter('face_into_gap').value)
        self.parking_style = str(self.get_parameter('parking_style').value)
        self.parallel_heading_sign = int(self.get_parameter('parallel_heading_sign').value)
        self.parallel_axle_offset_m = float(self.get_parameter('parallel_axle_offset_m').value)
        self.spot_marker_length = float(self.get_parameter('spot_marker_length').value)
        self.spot_marker_width = float(self.get_parameter('spot_marker_width').value)
        self.recompute_min_interval_sec = float(self.get_parameter('recompute_min_interval_sec').value)
        self.refine_enabled = bool(self.get_parameter('refine_enabled').value)
        self.refine_angle_range_deg = float(self.get_parameter('refine_angle_range_deg').value)
        self.refine_angle_step_deg = float(self.get_parameter('refine_angle_step_deg').value)
        self.refine_position_range_m = float(self.get_parameter('refine_position_range_m').value)
        self.refine_position_step_m = float(self.get_parameter('refine_position_step_m').value)

        map_topic = self.get_parameter('map_topic').value

        # ============================================================
        # STATE
        # ============================================================
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0
        self.have_pose = False
        self.parking_active = False
        self._last_compute_ns = 0
        self._stats = {}
        self._near_miss = None

        # ข้อมูลแมพปัจจุบัน (เก็บไว้ให้ probe helper เรียกใช้ได้)
        self._map_data = None
        self._map_width = 0
        self._map_height = 0
        self._map_resolution = 0.0
        self._map_origin_x = 0.0
        self._map_origin_y = 0.0

        # ============================================================
        # TF2
        # ============================================================
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.create_timer(0.1, self._update_robot_pose)

        # ============================================================
        # PUBLISHERS / SUBSCRIBERS
        # ============================================================
        self.pub_target = self.create_publisher(PoseStamped, '/parking/target_pose', 10)
        self.pub_marker = self.create_publisher(Marker, '/parking/spot_marker', 10)
        self.pub_bay_outline = self.create_publisher(Marker, '/parking/bay_outline_marker', 10)

        # /map มักถูก publish แบบ transient_local (latched) จาก slam_toolbox/map_server
        map_qos = QoSProfile(depth=1)
        map_qos.durability = QoSDurabilityPolicy.TRANSIENT_LOCAL
        map_qos.reliability = QoSReliabilityPolicy.RELIABLE
        map_qos.history = QoSHistoryPolicy.KEEP_LAST

        self.sub_map = self.create_subscription(OccupancyGrid, map_topic, self.map_cb, map_qos)
        self.sub_active = self.create_subscription(Bool, '/parking/active', self.active_cb, 10)
        self.sub_rescan = self.create_subscription(Bool, '/parking/rescan', self.rescan_cb, 10)

        n_angles = max(1, int(round(360.0 / self.angle_step_deg)))
        n_pos_per_axis = max(1, int(round((2 * self.search_radius_m) / self.position_step_m)) + 1)
        self.get_logger().info(
            'parking_spot_detector (U-shape bay, v3) started: '
            f'bay={self.bay_width_m:.2f}x{self.bay_depth_m:.2f}m, '
            f'search_radius={self.search_radius_m:.1f}m, '
            f'~{n_pos_per_axis}x{n_pos_per_axis} positions x {n_angles} angles '
            f'to test per recompute -- รอแมพและตำแหน่งรถ...'
        )

    # ================================================================
    # CALLBACKS
    # ================================================================
    def _update_robot_pose(self):
        try:
            tf = self.tf_buffer.lookup_transform('map', 'base_link', Time())
            self.robot_x = tf.transform.translation.x
            self.robot_y = tf.transform.translation.y
            self.robot_yaw = yaw_from_quaternion(tf.transform.rotation)
            self.have_pose = True
        except Exception:
            pass  # ยังไม่มี TF ให้ข้ามไปก่อน (เช่นตอนเพิ่งบูตระบบ)

    def active_cb(self, msg: Bool):
        self.parking_active = bool(msg.data)

    def rescan_cb(self, msg: Bool):
        if bool(msg.data):
            # บังคับให้รอบ /map ถัดไปคำนวณใหม่ทันที ไม่ต้องรอ recompute_min_interval_sec
            self._last_compute_ns = 0

    def map_cb(self, msg: OccupancyGrid):
        if self.parking_active:
            return  # กำลังจอดอัตโนมัติอยู่ ไม่ต้องคำนวณเป้าหมายใหม่ทับ
        if not self.have_pose:
            self.get_logger().warn(
                'ยังไม่มีตำแหน่งรถ (TF map->base_link) ข้ามรอบนี้ไปก่อน',
                throttle_duration_sec=5.0
            )
            return

        now = self.get_clock().now().nanoseconds
        if now - self._last_compute_ns < self.recompute_min_interval_sec * 1e9:
            return
        self._last_compute_ns = now

        self._analyze_map(msg)

    # ================================================================
    # MAP CELL HELPERS (ใช้ค่าจาก self._map_* ที่เก็บไว้ตอนเริ่ม _analyze_map)
    # ================================================================
    def _xy_to_rc(self, x, y):
        return (int((y - self._map_origin_y) / self._map_resolution),
                int((x - self._map_origin_x) / self._map_resolution))

    def _cell_value(self, x, y):
        r, c = self._xy_to_rc(x, y)
        if 0 <= r < self._map_height and 0 <= c < self._map_width:
            return self._map_data[r * self._map_width + c]
        return -1  # นอกแมพถือว่า unknown

    def _is_free(self, v) -> bool:
        return 0 <= v <= self.free_threshold

    def _is_occupied(self, v) -> bool:
        return v >= self.occupied_threshold

    def _ratio_free(self, points) -> float:
        """สัดส่วนจุดที่ 'ว่างชัดเจน' -- unknown (-1) ไม่นับเป็นว่าง (เข้มงวด
        เพราะเป็นพื้นที่ที่รถจะขับ/จอดจริง ต้องมั่นใจว่าว่างจริงจากแมพ)"""
        if not points:
            return 0.0
        cnt = sum(1 for (px, py) in points if self._is_free(self._cell_value(px, py)))
        return cnt / len(points)

    def _ratio_occupied(self, points) -> float:
        if not points:
            return 0.0
        cnt = sum(1 for (px, py) in points if self._is_occupied(self._cell_value(px, py)))
        return cnt / len(points)

    def _ratio_open(self, points) -> float:
        """สัดส่วนจุดที่ 'ไม่ใช่สิ่งกีดขวาง' -- unknown นับเป็นเปิดได้ (ผ่อนปรน
        กว่า _ratio_free เพราะปากช่องอาจยังสแกนไม่ทั่วถึง ขอแค่ไม่มีผนังขวาง)"""
        if not points:
            return 0.0
        cnt = sum(1 for (px, py) in points if not self._is_occupied(self._cell_value(px, py)))
        return cnt / len(points)

    # ================================================================
    # CORE ANALYSIS
    # ================================================================
    def _analyze_map(self, msg: OccupancyGrid):
        width = msg.info.width
        height = msg.info.height
        resolution = msg.info.resolution

        if width == 0 or height == 0 or resolution <= 0.0:
            return

        self._map_data = msg.data
        self._map_width = width
        self._map_height = height
        self._map_resolution = resolution
        self._map_origin_x = msg.info.origin.position.x
        self._map_origin_y = msg.info.origin.position.y

        best = self._search_best_bay()

        st = self._stats
        self.get_logger().info(
            'DEBUG ตกเงื่อนไข: '
            f'center_occupied={st.get("center_occupied")}, '
            f'interior={st.get("interior")}, back={st.get("back")}, '
            f'left={st.get("left")}, right={st.get("right")}, '
            f'mouth={st.get("mouth")}, passed={st.get("passed")}'
        )
        nm = self._near_miss
        if nm is not None:
            fmt = lambda v: 'n/a' if v is None else f'{v:.2f}'
            self.get_logger().info(
                f'DEBUG กรอบที่ใกล้ผ่านสุด (ตกที่ {nm["failed_at"]}): '
                f'cx={nm["cx"]:.2f}, cy={nm["cy"]:.2f}, theta={nm["theta"]:.0f}deg, '
                f'interior={nm["interior"]:.2f}, back={fmt(nm["back"])}, '
                f'left={fmt(nm["left"])}, right={fmt(nm["right"])}, mouth={fmt(nm["mouth"])}'
            )
        if best is None:
            self.get_logger().warn(
                f'ไม่พบช่องจอดที่ตรงเกณฑ์ในรัศมี {self.search_radius_m:.1f}m '
                f'รอบรถ (bay={self.bay_width_m:.2f}x{self.bay_depth_m:.2f}m) -- '
                'ลองปรับ bay_width_m/bay_depth_m ให้ตรงช่องจริง หรือลดเกณฑ์ '
                '*_ratio_min ลงดู',
                throttle_duration_sec=10.0
            )
            return

        self.get_logger().info(
            f'พบช่องจอด: cx={best["cx"]:.2f}, cy={best["cy"]:.2f}, '
            f'theta={math.degrees(best["theta"]):.0f}deg ห่างจากรถ '
            f'{best["distance"]:.2f}m (interior_free={best["interior_ratio"]:.2f}, '
            f'left={best["left_ratio"]:.2f}, right={best["right_ratio"]:.2f}, '
            f'back={best["back_ratio"]:.2f}, mouth_open={best["mouth_ratio"]:.2f}) '
            f'-> เป้าหมาย x={best["target_x"]:.2f}, y={best["target_y"]:.2f}, '
            f'yaw={math.degrees(best["target_yaw"]):.0f}deg'
        )
        self._publish_target(best['target_x'], best['target_y'], best['target_yaw'])
        self._publish_marker(best['target_x'], best['target_y'], best['target_yaw'])
        self._publish_bay_outline(best['cx'], best['cy'], best['theta'])

    def _search_best_bay(self):
        half_w = self.bay_width_m / 2.0
        half_d = self.bay_depth_m / 2.0
        angle_step_rad = math.radians(self.angle_step_deg)
        n_angles = max(1, int(round(2.0 * math.pi / angle_step_rad)))
        theta_list = [i * angle_step_rad for i in range(n_angles)]

        best = None  # dict เก็บผลลัพธ์ candidate ที่ดีที่สุด (ใกล้รถสุด) จนถึงตอนนี้
        self._stats = {'center_occupied': 0, 'interior': 0, 'back': 0,
                       'left': 0, 'right': 0, 'mouth': 0, 'passed': 0}
        self._near_miss = None

        for cx in frange(self.robot_x - self.search_radius_m,
                          self.robot_x + self.search_radius_m,
                          self.position_step_m):
            for cy in frange(self.robot_y - self.search_radius_m,
                              self.robot_y + self.search_radius_m,
                              self.position_step_m):

                if math.hypot(cx - self.robot_x, cy - self.robot_y) > self.search_radius_m:
                    continue

                # quick reject: จุดศูนย์กลางกรอบเองต้องไม่ใช่สิ่งกีดขวางชัดๆ ก่อน
                # ค่อยไปเสียเวลา probe เต็มรูปแบบ (ตัดทิ้ง candidate ส่วนใหญ่เร็วๆ)
                if self._is_occupied(self._cell_value(cx, cy)):
                    self._stats['center_occupied'] += 1
                    continue

                for theta in theta_list:
                    result = self._evaluate_bay(cx, cy, theta, half_w, half_d)
                    if result is None:
                        continue
                    if best is None or result['distance'] < best['distance']:
                        best = result

        if best is not None and self.refine_enabled:
            best = self._refine_bay(best, half_w, half_d)
        return best

    def _refine_bay(self, coarse, half_w, half_d):
        """ปรับกรอบหยาบให้ละเอียดขึ้น: สแกน (dx, dy, dtheta) ขั้นเล็กรอบกรอบที่เจอ
        เก็บทุกกรอบที่ผ่านเกณฑ์ แล้วใช้ค่าเฉลี่ย (centroid) ของกลุ่มที่ผ่านเป็นกรอบสุดท้าย
        -- ช่วงมุมที่ผ่านมักสมมาตรรอบมุมจริงของช่อง ค่าเฉลี่ยจึงขนานกับผนัง"""
        saved_stats, saved_nm = dict(self._stats), self._near_miss

        a_rng = math.radians(self.refine_angle_range_deg)
        a_step = math.radians(max(self.refine_angle_step_deg, 0.1))
        p_rng = self.refine_position_range_m
        p_step = max(self.refine_position_step_m, 0.005)

        passed = []
        for dth in frange(-a_rng, a_rng, a_step):
            theta = coarse['theta'] + dth
            for dx in frange(-p_rng, p_rng, p_step):
                for dy in frange(-p_rng, p_rng, p_step):
                    r = self._evaluate_bay(coarse['cx'] + dx, coarse['cy'] + dy,
                                           theta, half_w, half_d)
                    if r is not None:
                        r['_d'] = (dx, dy, dth)
                        passed.append(r)

        self._stats, self._near_miss = saved_stats, saved_nm  # ไม่ให้สถิติ debug เพี้ยน

        if not passed:
            return coarse

        n = len(passed)
        mdx = sum(r['_d'][0] for r in passed) / n
        mdy = sum(r['_d'][1] for r in passed) / n
        mdt = sum(r['_d'][2] for r in passed) / n

        refined = self._evaluate_bay(coarse['cx'] + mdx, coarse['cy'] + mdy,
                                     coarse['theta'] + mdt, half_w, half_d)
        self._stats, self._near_miss = saved_stats, saved_nm
        if refined is None:
            # centroid ไม่ผ่าน (รูปกลุ่มไม่นูน) -> ใช้กรอบที่ผ่านและใกล้ centroid สุด
            refined = min(
                passed,
                key=lambda r: ((r['_d'][0] - mdx) / p_step) ** 2
                              + ((r['_d'][1] - mdy) / p_step) ** 2
                              + ((r['_d'][2] - mdt) / a_step) ** 2)

        self.get_logger().info(
            f'refine: {n} กรอบผ่าน, มุมเปลี่ยน {math.degrees(refined["theta"] - coarse["theta"]):+.1f}deg '
            f'-> theta={math.degrees(normalize_angle(refined["theta"])):.1f}deg',
            throttle_duration_sec=5.0)
        return refined

    def _track_near_miss(self, failed_at, cx, cy, theta, interior, back, left, right, mouth):
        """เก็บกรอบที่ผ่านด่านภายในช่อง (interior) แล้วไปตกที่ด่านผนัง/ปากช่อง
        โดยเลือกอันที่ผ่านด่านไปได้ไกลที่สุดและคะแนนรวมสูงสุด"""
        order = {'back': 1, 'left': 2, 'right': 3, 'mouth': 4}
        parts = [v for v in (back, left, right, mouth) if v is not None]
        score = (order[failed_at], sum(parts))
        if self._near_miss is None or score > self._near_miss['score']:
            self._near_miss = {
                'score': score, 'failed_at': failed_at,
                'cx': cx, 'cy': cy, 'theta': math.degrees(theta),
                'interior': interior, 'back': back, 'left': left,
                'right': right, 'mouth': mouth,
            }

    def _evaluate_bay(self, cx, cy, theta, half_w, half_d):
        fx, fy = math.cos(theta), math.sin(theta)   # forward: มุ่งจากปากช่องเข้าหาก้นช่อง
        rx, ry = math.sin(theta), -math.cos(theta)   # right: ตั้งฉากกับ forward

        def world_pt(depth, lateral):
            return (cx + depth * fx + lateral * rx,
                    cy + depth * fy + lateral * ry)

        # --- พื้นที่ภายในช่อง (ต้องว่าง) ---
        interior_pts = [
            world_pt(d, l)
            for d in linspace(-half_d + self.wall_probe_offset_m,
                               half_d - self.wall_probe_offset_m, N_INTERIOR_DEPTH)
            for l in linspace(-half_w + self.wall_probe_offset_m,
                               half_w - self.wall_probe_offset_m, N_INTERIOR_LATERAL)
        ]
        interior_ratio = self._ratio_free(interior_pts)
        if interior_ratio < self.interior_free_ratio_min:
            self._stats['interior'] += 1
            return None

        # --- ก้นช่อง (ฝั่ง depth = +half_d, ต้องเป็นสิ่งกีดขวาง) ---
        back_pts = [
            world_pt(half_d + self.wall_probe_offset_m, l)
            for l in linspace(-half_w, half_w, N_WALL_SAMPLES)
        ]
        back_ratio = self._ratio_occupied(back_pts)
        if back_ratio < self.wall_fill_ratio_min:
            self._stats['back'] += 1
            self._track_near_miss('back', cx, cy, theta, interior_ratio, back_ratio, None, None, None)
            return None

        # --- ผนังซ้าย (lateral = -half_w, ต้องเป็นสิ่งกีดขวาง) ---
        left_pts = [
            world_pt(d, -half_w - self.wall_probe_offset_m)
            for d in linspace(-half_d, half_d, N_WALL_SAMPLES)
        ]
        left_ratio = self._ratio_occupied(left_pts)
        if left_ratio < self.wall_fill_ratio_min:
            self._stats['left'] += 1
            self._track_near_miss('left', cx, cy, theta, interior_ratio, back_ratio, left_ratio, None, None)
            return None

        # --- ผนังขวา (lateral = +half_w, ต้องเป็นสิ่งกีดขวาง) ---
        right_pts = [
            world_pt(d, half_w + self.wall_probe_offset_m)
            for d in linspace(-half_d, half_d, N_WALL_SAMPLES)
        ]
        right_ratio = self._ratio_occupied(right_pts)
        if right_ratio < self.wall_fill_ratio_min:
            self._stats['right'] += 1
            self._track_near_miss('right', cx, cy, theta, interior_ratio, back_ratio, left_ratio, right_ratio, None)
            return None

        # --- ปากช่อง (ฝั่ง depth = -half_d, ต้องโล่ง ไม่มีสิ่งกีดขวางขวาง) ---
        mouth_pts = [
            world_pt(-half_d - self.mouth_probe_offset_m, l)
            for l in linspace(-half_w, half_w, N_MOUTH_SAMPLES)
        ]
        mouth_ratio = self._ratio_open(mouth_pts)
        if mouth_ratio < self.mouth_open_ratio_min:
            self._stats['mouth'] += 1
            self._track_near_miss('mouth', cx, cy, theta, interior_ratio, back_ratio, left_ratio, right_ratio, mouth_ratio)
            return None
        self._stats['passed'] += 1

        # ผ่านครบทุกเงื่อนไข -> คำนวณเป้าหมายจริง (ลึกเข้าไปในช่อง
        # target_depth_ratio ของความลึกทั้งหมด นับจากปากช่อง)
        depth_from_center = (self.target_depth_ratio - 0.5) * self.bay_depth_m
        target_x, target_y = world_pt(depth_from_center, 0.0)

        if self.parking_style == 'parallel':
            # จอดเทียบข้าง: หันหัวขนานแนวถนน (ตั้งฉากกับทิศ theta ที่ชี้เข้าก้นช่อง)
            yaw_a = normalize_angle(theta + math.pi / 2.0)
            yaw_b = normalize_angle(theta - math.pi / 2.0)
            if self.parallel_heading_sign > 0:
                target_yaw = yaw_a
            elif self.parallel_heading_sign < 0:
                target_yaw = yaw_b
            else:
                target_yaw = min(
                    (yaw_a, yaw_b),
                    key=lambda y: abs(normalize_angle(y - self.robot_yaw)))
            # เลื่อนจุดเป้าหมายถอยหลังตามทิศหัวรถ ให้กึ่งกลางตัวรถอยู่กลางช่อง
            # (เพลาหลังอยู่หลังกึ่งกลางตัวรถ)
            target_x -= self.parallel_axle_offset_m * math.cos(target_yaw)
            target_y -= self.parallel_axle_offset_m * math.sin(target_yaw)
        else:
            # face_into_gap=True -> หันหัวเข้าก้นช่อง (ทิศ theta ตรงๆ)
            # face_into_gap=False -> หันหัวออกปากช่อง (ทิศตรงข้าม)
            target_yaw = theta if self.face_into_gap else normalize_angle(theta + math.pi)

        distance = math.hypot(target_x - self.robot_x, target_y - self.robot_y)

        return {
            'cx': cx, 'cy': cy, 'theta': theta,
            'target_x': target_x, 'target_y': target_y, 'target_yaw': target_yaw,
            'distance': distance,
            'interior_ratio': interior_ratio, 'back_ratio': back_ratio,
            'left_ratio': left_ratio, 'right_ratio': right_ratio,
            'mouth_ratio': mouth_ratio,
        }

    # ================================================================
    # PUBLISH HELPERS
    # ================================================================
    def _publish_target(self, x, y, yaw):
        msg = PoseStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'map'
        msg.pose.position.x = x
        msg.pose.position.y = y
        msg.pose.position.z = 0.0
        qx, qy, qz, qw = quaternion_from_yaw(yaw)
        msg.pose.orientation.x = qx
        msg.pose.orientation.y = qy
        msg.pose.orientation.z = qz
        msg.pose.orientation.w = qw
        self.pub_target.publish(msg)

    def _publish_marker(self, x, y, yaw):
        marker = Marker()
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.header.frame_id = 'map'
        marker.ns = 'parking_spot'
        marker.id = 0
        marker.type = Marker.CUBE
        marker.action = Marker.ADD
        marker.pose.position.x = x
        marker.pose.position.y = y
        marker.pose.position.z = 0.02
        qx, qy, qz, qw = quaternion_from_yaw(yaw)
        marker.pose.orientation.x = qx
        marker.pose.orientation.y = qy
        marker.pose.orientation.z = qz
        marker.pose.orientation.w = qw
        marker.scale.x = self.spot_marker_length
        marker.scale.y = self.spot_marker_width
        marker.scale.z = 0.05
        marker.color.r = 0.0
        marker.color.g = 1.0
        marker.color.b = 0.0
        marker.color.a = 0.5
        marker.lifetime.sec = 0
        self.pub_marker.publish(marker)

    def _publish_bay_outline(self, cx, cy, theta):
        """วาดเส้นขอบช่องตัวยูที่เจอ: ปากซ้าย -> ก้นซ้าย -> ก้นขวา -> ปากขวา
        (ไม่ปิดเส้นกลับมาปากซ้าย เพราะฝั่งปากช่องคือฝั่งที่เปิด/ไม่มีผนังจริง)"""
        half_w = self.bay_width_m / 2.0
        half_d = self.bay_depth_m / 2.0
        fx, fy = math.cos(theta), math.sin(theta)
        rx, ry = math.sin(theta), -math.cos(theta)

        def world_pt(depth, lateral):
            return (cx + depth * fx + lateral * rx,
                    cy + depth * fy + lateral * ry)

        mouth_left = world_pt(-half_d, -half_w)
        back_left = world_pt(half_d, -half_w)
        back_right = world_pt(half_d, half_w)
        mouth_right = world_pt(-half_d, half_w)

        marker = Marker()
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.header.frame_id = 'map'
        marker.ns = 'parking_bay_outline'
        marker.id = 1
        marker.type = Marker.LINE_STRIP
        marker.action = Marker.ADD
        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.04  # ความหนาเส้น
        marker.color.r = 1.0
        marker.color.g = 0.6
        marker.color.b = 0.0
        marker.color.a = 0.9
        marker.lifetime.sec = 0
        marker.points = [
            Point(x=mouth_left[0], y=mouth_left[1], z=0.05),
            Point(x=back_left[0], y=back_left[1], z=0.05),
            Point(x=back_right[0], y=back_right[1], z=0.05),
            Point(x=mouth_right[0], y=mouth_right[1], z=0.05),
        ]
        self.pub_bay_outline.publish(marker)


def main(args=None):
    rclpy.init(args=args)
    node = ParkingSpotDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
