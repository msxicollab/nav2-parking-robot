#!/usr/bin/env python3
"""
odom_to_tf.py
...
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped


class OdomToTF(Node):
    def __init__(self):
        super().__init__('odom_to_tf')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('publish_tf', True)

        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.publish_tf = self.get_parameter('publish_tf').value

        self.br = TransformBroadcaster(self)

        # FIX: ESP32 publish /odom เป็น best_effort (ตั้งใจ เพื่อกัน reliable publish
        # บล็อกนานตอน WiFi packet loss) แต่ create_subscription(..., 10) เดิมสร้าง
        # QoS แบบ reliable ตาม default ทำให้ mismatch — subscriber ไม่ได้รับ /odom
        # เลยสักข้อความเดียว (ยืนยันจาก log: "New publisher discovered on topic
        # '/odom', offering incompatible QoS ... Last incompatible policy: RELIABILITY")
        odom_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )
        self.sub = self.create_subscription(Odometry, '/odom', self.odom_cb, odom_qos)

        self.get_logger().info(
            f'odom_to_tf started: {self.odom_frame} -> {self.base_frame} '
            f'(publish_tf={self.publish_tf})')

    def odom_cb(self, msg: Odometry):
        if not self.publish_tf:
            return

        t = TransformStamped()
        t.header.stamp = msg.header.stamp
        t.header.frame_id = self.odom_frame
        t.child_frame_id = self.base_frame

        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z
        t.transform.rotation = msg.pose.pose.orientation

        self.br.sendTransform(t)


def main(args=None):
    rclpy.init(args=args)
    node = OdomToTF()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()