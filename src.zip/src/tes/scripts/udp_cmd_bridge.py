#!/usr/bin/env python3

import socket
import struct
import time

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from geometry_msgs.msg import TwistStamped


MAGIC = 0xC1A1
VERSION = 1
PORT = 9999
PACK_FORMAT = '<HBBIffIH'
PACK_SIZE = struct.calcsize(PACK_FORMAT)
SEND_HZ = 30.0


def checksum_without_last_field(packet_without_checksum: bytes) -> int:
    c = 0xA5A5
    for b in packet_without_checksum:
        c = ((c << 5) ^ (c >> 11) ^ b) & 0xFFFF
    return c


class UdpCmdBridge(Node):
    def __init__(self):
        super().__init__('udp_cmd_bridge')

        self.declare_parameter('esp32_ip', '')
        self.declare_parameter('udp_port', PORT)
        self.declare_parameter('cmd_topic', '/cmd_vel')
        self.declare_parameter('msg_type', 'twist')
        self.declare_parameter('send_hz', SEND_HZ)
        self.declare_parameter('max_vx', 3.0)
        self.declare_parameter('max_omega', 20.0)

        self.esp32_ip = str(self.get_parameter('esp32_ip').value)
        self.udp_port = int(self.get_parameter('udp_port').value)
        self.cmd_topic = str(self.get_parameter('cmd_topic').value)
        self.msg_type = str(self.get_parameter('msg_type').value).lower()
        self.send_hz = float(self.get_parameter('send_hz').value)
        self.max_vx = float(self.get_parameter('max_vx').value)
        self.max_omega = float(self.get_parameter('max_omega').value)

        if not self.esp32_ip:
            raise RuntimeError(
                'esp32_ip is required. Example: '
                'ros2 run ... --ros-args -p esp32_ip:=10.38.184.85'
            )

        if self.msg_type not in ('twist', 'twist_stamped'):
            raise RuntimeError("msg_type must be 'twist' or 'twist_stamped'")

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.target = (self.esp32_ip, self.udp_port)

        self.vx = 0.0
        self.omega = 0.0
        self.seq = 0
        self.last_ros_msg_time = time.monotonic()
        self.sent = 0

        if self.msg_type == 'twist':
            self.sub = self.create_subscription(
                Twist, self.cmd_topic, self.twist_cb, 10
            )
        else:
            self.sub = self.create_subscription(
                TwistStamped, self.cmd_topic, self.twist_stamped_cb, 10
            )

        self.timer = self.create_timer(1.0 / self.send_hz, self.send_packet)

        self.get_logger().info(
            f'RAW UDP cmd_vel bridge started: {self.cmd_topic} '
            f'({self.msg_type}) -> {self.esp32_ip}:{self.udp_port} '
            f'@ {self.send_hz:.1f} Hz'
        )

    def set_command(self, vx, omega):
        self.vx = max(-self.max_vx, min(self.max_vx, float(vx)))
        self.omega = max(-self.max_omega, min(self.max_omega, float(omega)))
        self.last_ros_msg_time = time.monotonic()

    def twist_cb(self, msg):
        self.set_command(msg.linear.x, msg.angular.z)

    def twist_stamped_cb(self, msg):
        self.set_command(msg.twist.linear.x, msg.twist.angular.z)

    def send_packet(self):
        # Always send at a fixed rate. This is intentional: ROS callback jitter
        # must not become motor-command jitter.
        vx = self.vx
        omega = self.omega
        now_ms = int(time.monotonic() * 1000.0) & 0xFFFFFFFF

        header_and_data = struct.pack(
            '<HBBIffI',
            MAGIC,
            VERSION,
            0,
            self.seq & 0xFFFFFFFF,
            vx,
            omega,
            now_ms,
        )
        crc = checksum_without_last_field(header_and_data)
        packet = header_and_data + struct.pack('<H', crc)

        if len(packet) != PACK_SIZE:
            self.get_logger().error(f'Internal packet size error: {len(packet)}')
            return

        try:
            self.sock.sendto(packet, self.target)
            self.sent += 1
            self.seq = (self.seq + 1) & 0xFFFFFFFF
        except OSError as e:
            self.get_logger().error(f'UDP send failed: {e}')

    def destroy_node(self):
        # Send a few zero commands before closing so a healthy ESP32 receives
        # an explicit stop even if the bridge is stopped manually.
        self.vx = 0.0
        self.omega = 0.0
        for _ in range(3):
            self.send_packet()
            time.sleep(0.01)
        self.sock.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = UdpCmdBridge()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        if node is not None:
            node.get_logger().error(str(e))
        else:
            print(f'udp_cmd_bridge: {e}')
    finally:
        if node is not None:
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
