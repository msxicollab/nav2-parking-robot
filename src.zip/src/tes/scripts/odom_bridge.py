#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node

from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from rclpy.qos import HistoryPolicy

from nav_msgs.msg import Odometry
from car1_msgs.msg import OdomLite


class OdomBridge(Node):

    def __init__(self):
        super().__init__('odom_bridge')

        # ============================================
        # QoS สำหรับรับ /odom_lite จาก ESP32
        # ESP32 ใช้ BEST_EFFORT
        # ============================================

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )

        # ============================================
        # Subscribe /odom_lite
        # ============================================

        self.sub = self.create_subscription(
            OdomLite,
            '/odom_lite',
            self.odom_lite_callback,
            qos
        )

        # ============================================
        # Publish standard nav_msgs/Odometry
        # ============================================

        self.pub = self.create_publisher(
            Odometry,
            '/odom',
            10
        )

        # ============================================
        # Integrated pose
        # ============================================

        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0

        self.last_stamp = None

        # ============================================
        # Log
        # ============================================

        self.get_logger().info('====================================')
        self.get_logger().info(' ODOM BRIDGE STARTED')
        self.get_logger().info(' /odom_lite -> /odom')
        self.get_logger().info(' QoS: BEST_EFFORT')
        self.get_logger().info(' vx -> linear.x')
        self.get_logger().info(' vyaw -> angular.z')
        self.get_logger().info('====================================')

    def odom_lite_callback(self, msg):

        # ============================================
        # ESP32 timestamp
        # ============================================

        current_stamp = (
            float(msg.stamp.sec)
            + float(msg.stamp.nanosec) * 1e-9
        )

        # ============================================
        # ครั้งแรกยังคำนวณ dt ไม่ได้
        # ============================================

        if self.last_stamp is None:
            self.last_stamp = current_stamp
            return

        # ============================================
        # Calculate dt
        # ============================================

        dt = current_stamp - self.last_stamp

        self.last_stamp = current_stamp

        # ป้องกัน timestamp ผิด (ไม่ publish รอบนี้ เพราะคำนวณ dt ไม่ได้จริงๆ)
        if dt <= 0.0:
            return

        # ป้องกัน timestamp กระโดด
        # หมายเหตุ: เดิมโค้ดจะ `return` ตรงนี้ ทำให้ /odom หยุด publish
        # ไปทั้งรอบ ส่งผลให้ TF odom->base_link ค้าง และ Nav2
        # progress_checker เข้าใจผิดว่ารถไม่ขยับ (ทริกเกอร์ recovery/backup)
        # ตอนนี้แก้เป็น: ข้ามการ integrate ตำแหน่งในรอบนั้น (dt=0)
        # แต่ยังคง publish /odom ต่อไปตามปกติ
        if dt > 0.5:
            self.get_logger().warn(
                f'Large dt detected: {dt:.3f} sec (skipping integration this cycle)'
            )
            dt = 0.0

        # ============================================
        # Read velocity
        # ============================================

        vx = float(msg.vx)
        vyaw = float(msg.vyaw)

        # ============================================
        # Integrate velocity -> pose
        #
        # vx   = forward velocity m/s
        # vyaw = yaw velocity rad/s
        # ============================================

        self.x += (
            vx *
            math.cos(self.yaw) *
            dt
        )

        self.y += (
            vx *
            math.sin(self.yaw) *
            dt
        )

        self.yaw += vyaw * dt

        # Normalize yaw to [-pi, +pi]

        self.yaw = math.atan2(
            math.sin(self.yaw),
            math.cos(self.yaw)
        )

        # ============================================
        # Create Odometry message
        # ============================================

        odom = Odometry()

        # หมายเหตุ: เดิมใช้ msg.stamp (นาฬิกาของ ESP32) ตรงนี้
        # แต่ ESP32 clock ไม่ sync กับ system clock ของ PC ทำให้
        # tf2_monitor เห็น negative delay บน odom->base_link
        # เปลี่ยนมาใช้เวลาของ ROS node (system clock) แทน เพื่อให้
        # timestamp สอดคล้องกับ node อื่นๆ ที่ใช้ system time เหมือนกัน
        odom.header.stamp = self.get_clock().now().to_msg()

        # Parent frame
        odom.header.frame_id = 'odom'

        # Robot frame
        odom.child_frame_id = 'base_link'

        # ============================================
        # Position
        # ============================================

        odom.pose.pose.position.x = self.x
        odom.pose.pose.position.y = self.y
        odom.pose.pose.position.z = 0.0

        # ============================================
        # Quaternion from yaw
        # ============================================

        odom.pose.pose.orientation.x = 0.0
        odom.pose.pose.orientation.y = 0.0

        odom.pose.pose.orientation.z = math.sin(
            self.yaw / 2.0
        )

        odom.pose.pose.orientation.w = math.cos(
            self.yaw / 2.0
        )

        # ============================================
        # Velocity
        # ============================================

        odom.twist.twist.linear.x = vx
        odom.twist.twist.linear.y = 0.0
        odom.twist.twist.linear.z = 0.0

        odom.twist.twist.angular.x = 0.0
        odom.twist.twist.angular.y = 0.0
        odom.twist.twist.angular.z = vyaw

        # ============================================
        # Pose covariance
        # ============================================

        odom.pose.covariance[0] = 0.05
        odom.pose.covariance[7] = 0.05
        odom.pose.covariance[35] = 0.10

        # ============================================
        # Twist covariance
        # ============================================

        odom.twist.covariance[0] = 0.05
        odom.twist.covariance[35] = 0.10

        # ============================================
        # Publish
        # ============================================

        self.pub.publish(odom)


def main(args=None):

    rclpy.init(args=args)

    node = OdomBridge()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()