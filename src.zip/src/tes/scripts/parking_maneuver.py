#!/usr/bin/env python3
"""
parking_maneuver.py (Nav2 edition)

*** เปลี่ยนสถาปัตยกรรมใหม่ทั้งหมด ***
เดิม node นี้คำนวณมุมเลี้ยว/ระยะถอยเอง (state machine TURN_IN -> STRAIGHTEN) จาก
heading เป้าหมายที่ parking_spot_detector.py ตรวจเจอ ปัญหาคือไม่มีการเลี่ยงสิ่งกีดขวาง
จริงระหว่างเคลื่อนที่ (เช็คแค่ระยะ LiDAR ด้านหลังจุดเดียว) และถ้า heading ที่จำไว้กับ
ตำแหน่งรถตอนกด B ไม่สัมพันธ์กันอีกต่อไป (เช่นรถเลี้ยวโค้งไปก่อนกด) จะคำนวณมุมผิดได้

เวอร์ชันนี้เปลี่ยนมาใช้ **Nav2** วางแผนเส้นทางให้แทน:
  - planner_server ใช้ SmacPlannerHybrid + motion_model REEDS_SHEPP และ allow_reversing
    ซึ่งวางแผนเส้นทางเลี้ยว-ถอยแบบรถจริงได้ พร้อมเลี่ยงสิ่งกีดขวางจาก costmap (LiDAR
    รอบคัน ไม่ใช่แค่ด้านหลังจุดเดียวแบบเดิม)
  - node นี้ทำหน้าที่แค่เป็น "action client" เรียก /navigate_to_pose
    (nav2_msgs/action/NavigateToPose) โดยส่งตำแหน่งช่องจอดที่ parking_spot_detector.py
    เจอ เป็นเป้าหมายเท่านั้น ที่เหลือ Nav2 จัดการให้ทั้งหมด

Flow:
  กด B -> เช็คว่ามี target_pose ที่ยังสดอยู่ไหม (อายุ/ระยะห่างจากตำแหน่งรถต้องผ่านเกณฑ์
          เหมือนเดิม กันช่องเก่าที่รถเลี้ยว/ขับห่างไปแล้ว)
       -> แปลง target_pose จาก frame เดิม (odom, มาจาก parking_spot_detector.py)
          เป็น frame 'map' ผ่าน tf2 (Nav2 bt_navigator ทำงานใน frame 'map' เป็นหลัก)
          *** ใช้ transform map<->odom "ล่าสุดที่มี" ตอนแปลง (ไม่ใช่ transform ณ เวลาที่
          ตรวจเจอเสา) เพราะพิกัด odom ของจุดจริงไม่เคยเปลี่ยน มีแต่ค่า map<->odom ที่
          slam_toolbox ปรับแก้ละเอียดอยู่ตลอด การใช้ transform เก่าจะพาเอาความเพี้ยนที่ยัง
          ไม่ได้รับการแก้ไขล่าสุดติดมาด้วย ***
       -> ส่ง action goal ไปที่ Nav2 แล้วรอผล
  กด B ซ้ำ (cancel) -> ยกเลิก Nav2 goal ที่กำลังทำอยู่

Subscribe:
  /parking/command      (std_msgs/String)             "start" | "cancel"
  /parking/target_pose  (geometry_msgs/PoseStamped)    จาก parking_spot_detector.py (frame odom)

Publish:
  /parking/status   (std_msgs/String)   "in_progress" | "success" | "failed" | "cancelled"

Action client:
  /navigate_to_pose (nav2_msgs/action/NavigateToPose)

หมายเหตุ: ต้องมี Nav2 stack รันอยู่แล้ว (ดู car1_bringup.launch.py ส่วน "Nav2 stack")
และต้องมี TF map -> base_link ใช้งานได้ (มาจาก slam_toolbox + odom_to_tf.py + URDF)
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.time import Time
from rclpy.duration import Duration

from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped, Twist
from sensor_msgs.msg import LaserScan
from rclpy.qos import qos_profile_sensor_data
from nav2_msgs.action import NavigateToPose

import tf2_ros
import tf2_geometry_msgs  # noqa: F401  (import ไว้เพื่อลงทะเบียน transform ของ PoseStamped)


# GoalStatus ตาม action_msgs/msg/GoalStatus (ค่าคงที่มาตรฐานของ ROS2 action)
STATUS_SUCCEEDED = 4
STATUS_CANCELED = 5
STATUS_ABORTED = 6


class ParkingManeuver(Node):

    IDLE = 'IDLE'
    NAVIGATING = 'NAVIGATING'
    STOPPED = 'STOPPED'
    FINAL_REVERSE = 'FINAL_REVERSE'
    ALIGNING = 'ALIGNING'

    def __init__(self):
        super().__init__('parking_maneuver')

        # ============================================================
        # PARAMETERS
        # ============================================================
        # ป้องกันปัญหา "เจอช่องแล้ว แต่รถเลี้ยวโค้ง/ขับต่อไปไกลก่อนกด B" เหมือนเดิม
        self.declare_parameter('target_max_age_sec', 3.0)      # วิ นับจากตรวจเจอช่อง
        self.declare_parameter('max_target_distance', 1.2)     # m ระยะห่างสูงสุดจากรถถึงช่อง
        self.declare_parameter('nav2_action_name', 'navigate_to_pose')
        self.declare_parameter('nav2_server_wait_sec', 5.0)     # รอ action server พร้อมกี่วิ
        # ค่า tf transform timeout: ตั้งไว้ 0.0 (ไม่รอ) โดยตั้งใจ เพราะ node นี้ใช้
        # rclpy.spin() แบบ single-threaded ธรรมดา ถ้าตั้งค่าที่ > 0 แล้ว transform ยัง
        # ไม่มีในบัฟเฟอร์ จะบล็อกรอเฉย ๆ โดยไม่มีเธรดอื่นไป spin รับ TF ใหม่เข้ามาเลย
        # (deadlock) ในทางปฏิบัติ TF map->odom/base_link ถูกส่งต่อเนื่องอยู่แล้วตลอดเวลา
        # ที่ระบบทำงานปกติ จึงมักมีอยู่ในบัฟเฟอร์ทันทีโดยไม่ต้องรอ
        self.declare_parameter('tf_transform_timeout_sec', 0.0)

        # ---- ขั้นถอยปิดท้าย: หลัง Nav2 ถึงเป้าแล้ว ถอยตรงต่อโดยอ่านระยะกำแพงจาก LiDAR ----
        # ปิดไว้เป็นค่าเริ่มต้น ต้องวัด lidar_to_rear_m จริงก่อนเปิด
        self.declare_parameter('final_reverse_enable', True)
        self.declare_parameter('cmd_topic', '/cmd_vel_auto')      # เข้า twist_mux (priority 100)
        self.declare_parameter('scan_topic', '/scan_filtered')
        # มุมของ "ด้านหน้ารถ" ในเฟรมของ scan (rad) 0.0 = LiDAR หมุนตรงกับตัวรถ (x ไปหน้า)
        self.declare_parameter('lidar_forward_yaw_rad', 0.0)
        # ระยะตามแนวตัวรถจากตัว LiDAR ถึงกันชนท้าย (m) *** ต้องวัดจริง ***
        self.declare_parameter('lidar_to_rear_m', 0.10)
        self.declare_parameter('rear_half_width_m', 0.15)         # ครึ่งความกว้างที่ใช้หากำแพงด้านหลัง
        self.declare_parameter('target_gap_m', 0.04)              # ระยะท้ายรถถึงกำแพงที่ต้องการ
        self.declare_parameter('brake_margin_m', 0.02)            # สั่งหยุดก่อนถึงเป้านี้ กันไถลเลย
        self.declare_parameter('reverse_speed', 0.32)             # m/s ต้อง >= ความเร็วที่รถเริ่มขยับ (~0.3)
        self.declare_parameter('max_reverse_distance_m', 0.25)    # ถอยเกินนี้ (วัดจาก TF) หยุดทันที
        self.declare_parameter('final_reverse_timeout_sec', 4.0)
        self.declare_parameter('scan_max_age_sec', 0.3)           # scan เก่ากว่านี้ = หยุด

        # ---- ขั้นจัดตัวรถให้ขนานกำแพง (ทำหลัง Nav2 ถึงเป้า ก่อนถอยปิดท้าย) ----
        # วัดมุมกำแพงจาก LiDAR แล้วขยับ ถอย/เดินหน้า สลับกันพร้อมเลี้ยว (wiggle แบบ 3-point turn)
        # จนมุมคลาดเคลื่อนน้อยกว่า align_tolerance_deg
        self.declare_parameter('align_enable', True)
        self.declare_parameter('align_tolerance_deg', 3.0)        # ถือว่าขนานแล้วเมื่อคลาดไม่เกินนี้
        self.declare_parameter('align_reference_offset_deg', 0.0)  # 0 = ขนานกำแพง, 90 = ตั้งฉาก
        self.declare_parameter('align_max_legs', 6)               # จำนวนช่วงขยับสูงสุด (ถอย/เดินหน้า)
        self.declare_parameter('align_leg_distance_m', 0.08)      # ระยะต่อช่วง (วัดจาก TF)
        self.declare_parameter('align_speed', 0.22)               # m/s (>= ความเร็วที่รถเริ่มขยับ)
        self.declare_parameter('align_omega_gain', 2.0)           # rad/s ต่อ rad ของมุมคลาด
        self.declare_parameter('align_omega_min', 0.30)           # rad/s
        self.declare_parameter('align_omega_max', 0.80)           # rad/s (อย่าเกินที่ servo เลี้ยวได้)
        self.declare_parameter('align_min_clearance_m', 0.1)     # หยุดช่วงนั้นถ้าระยะว่างเหลือน้อยกว่านี้
        self.declare_parameter('align_timeout_sec', 25.0)
        self.declare_parameter('align_settle_sec', 0.4)           # หยุดนิ่งก่อนวัดมุมแต่ละรอบ
        self.declare_parameter('align_range_max_m', 1.0)          # ใช้จุด LiDAR ใกล้กว่านี้หามุมกำแพง
        self.declare_parameter('align_range_min_m', 0.12)         # ตัดจุดที่เป็นตัวรถเอง
        self.declare_parameter('align_min_segments', 15)
        self.declare_parameter('align_min_coherence', 0.5)        # 0-1 ยิ่งสูงยิ่งเข้มว่าต้องเป็นเส้นตรงชัด
        self.declare_parameter('lidar_to_front_m', 0.25)          # *** ต้องวัดจริง *** LiDAR -> กันชนหน้า
        # ถอยปิดท้ายพร้อมประคองมุมให้ขนานไปด้วย
        self.declare_parameter('final_reverse_heading_hold', True)
        self.declare_parameter('heading_hold_gain', 1.0)
        self.declare_parameter('heading_hold_max', 0.30)          # rad/s

        self.target_max_age_sec = float(self.get_parameter('target_max_age_sec').value)
        self.max_target_distance = float(self.get_parameter('max_target_distance').value)
        nav2_action_name = str(self.get_parameter('nav2_action_name').value)
        self.nav2_server_wait_sec = float(self.get_parameter('nav2_server_wait_sec').value)
        self.tf_timeout = Duration(
            seconds=float(self.get_parameter('tf_transform_timeout_sec').value)
        )

        self.fr_enable = bool(self.get_parameter('final_reverse_enable').value)
        self.fr_cmd_topic = str(self.get_parameter('cmd_topic').value)
        self.fr_scan_topic = str(self.get_parameter('scan_topic').value)
        self.fr_lidar_yaw = float(self.get_parameter('lidar_forward_yaw_rad').value)
        self.fr_lidar_to_rear = float(self.get_parameter('lidar_to_rear_m').value)
        self.fr_half_width = float(self.get_parameter('rear_half_width_m').value)
        self.fr_target_gap = float(self.get_parameter('target_gap_m').value)
        self.fr_brake_margin = float(self.get_parameter('brake_margin_m').value)
        self.fr_speed = abs(float(self.get_parameter('reverse_speed').value))
        self.fr_max_dist = float(self.get_parameter('max_reverse_distance_m').value)
        self.fr_timeout = float(self.get_parameter('final_reverse_timeout_sec').value)
        self.fr_scan_max_age = float(self.get_parameter('scan_max_age_sec').value)

        gp = lambda n: self.get_parameter(n).value
        self.al_enable = bool(gp('align_enable'))
        self.al_tol = math.radians(float(gp('align_tolerance_deg')))
        self.al_ref = math.radians(float(gp('align_reference_offset_deg')))
        self.al_max_legs = int(gp('align_max_legs'))
        self.al_leg_dist = float(gp('align_leg_distance_m'))
        self.al_speed = abs(float(gp('align_speed')))
        self.al_w_gain = float(gp('align_omega_gain'))
        self.al_w_min = float(gp('align_omega_min'))
        self.al_w_max = float(gp('align_omega_max'))
        self.al_min_clear = float(gp('align_min_clearance_m'))
        self.al_timeout = float(gp('align_timeout_sec'))
        self.al_settle = float(gp('align_settle_sec'))
        self.al_r_max = float(gp('align_range_max_m'))
        self.al_r_min = float(gp('align_range_min_m'))
        self.al_min_seg_n = int(gp('align_min_segments'))
        self.al_min_coh = float(gp('align_min_coherence'))
        self.fr_lidar_to_front = float(gp('lidar_to_front_m'))
        self.hh_enable = bool(gp('final_reverse_heading_hold'))
        self.hh_gain = float(gp('heading_hold_gain'))
        self.hh_max = float(gp('heading_hold_max'))

        # ============================================================
        # STATE
        # ============================================================
        self.state = self.IDLE
        self.target_pose = None   # เป้าหมายล่าสุดจาก parking_spot_detector.py (frame เดิม)
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.have_robot_pose = False
        self._goal_handle = None  # goal handle ของ Nav2 ที่กำลังทำงานอยู่ (ถ้ามี)
        self._goal_pose = None    # เป้าหมายที่ส่งให้ Nav2 (frame map) ไว้เทียบตอนจอดเสร็จ
        self._last_scan = None
        self._last_scan_rx = None
        self._fr_timer = None
        self._fr_start_time = None
        self._fr_start_xy = None
        self._al_timer = None
        self._al_t0 = None
        self._al_phase = 'settle'
        self._al_phase_t0 = None
        self._al_legs = 0
        self._al_dir = 0            # +1 เดินหน้า, -1 ถอย (ทิศของช่วงล่าสุด)
        self._al_omega = 0.0
        self._al_leg_start_xy = None

        # ============================================================
        # TF2 (แปลง target_pose ไป frame 'map' ก่อนส่งให้ Nav2 + ใช้เช็คระยะห่าง)
        # ============================================================
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # ============================================================
        # ACTION CLIENT
        # ============================================================
        self._nav_client = ActionClient(self, NavigateToPose, nav2_action_name)

        # ============================================================
        # PUBLISHERS / SUBSCRIBERS
        # ============================================================
        self.pub_status = self.create_publisher(String, '/parking/status', 10)
        self.sub_command = self.create_subscription(String, '/parking/command', self.command_cb, 10)
        self.pub_cmd = self.create_publisher(Twist, self.fr_cmd_topic, 10)
        self.sub_scan = self.create_subscription(
            LaserScan, self.fr_scan_topic, self._scan_cb, qos_profile_sensor_data
        )
        self.sub_target = self.create_subscription(
            PoseStamped, '/parking/target_pose', self.target_pose_cb, 10
        )

        # อัปเดตตำแหน่งรถ (frame 'map') เป็นระยะ ผ่าน TF แทนการอ่าน /odom ตรง ๆ
        # เพื่อให้พิกัดอยู่ frame เดียวกับ target_pose หลัง transform ตอนเทียบระยะทาง
        self.create_timer(0.2, self._update_robot_pose)

        self.get_logger().info(
            f'parking_maneuver (Nav2 edition) started -> ใช้ action "{nav2_action_name}" '
            f'(target max age={self.target_max_age_sec:.1f}s, max distance='
            f'{self.max_target_distance:.2f}m) รอคำสั่ง start '
            f'(ต้องมี /parking/target_pose สดจาก parking_spot_detector.py ก่อนถึงจะเริ่มได้)'
        )

    # ================================================================
    # POSE TRACKING (ผ่าน TF map->base_link)
    # ================================================================
    def _update_robot_pose(self):
        try:
            tf = self.tf_buffer.lookup_transform('map', 'base_link', Time())
            self.robot_x = tf.transform.translation.x
            self.robot_y = tf.transform.translation.y
            self.have_robot_pose = True
        except Exception:
            pass  # ยังไม่มี TF ให้ข้ามไปก่อน (เช่นตอนเพิ่งบูตระบบ)

    # ================================================================
    # CALLBACKS
    # ================================================================
    def target_pose_cb(self, msg: PoseStamped):
        self.target_pose = msg

    def command_cb(self, msg: String):
        cmd = msg.data.strip().lower()
        if cmd == 'start':
            if self.state in (self.IDLE, self.STOPPED):
                self._start_parking()
        elif cmd == 'cancel':
            self._cancel_parking()

    # ================================================================
    # START / CANCEL
    # ================================================================
    def _start_parking(self):
        if self.target_pose is None:
            self.get_logger().error(
                'ยังไม่พบช่องจอดว่างเลย (ไม่มีข้อมูลจาก /parking/target_pose) -> '
                'กรุณาขับรถผ่านช่องจอดที่ว่างก่อน แล้วค่อยกด B ใหม่'
            )
            self._publish_status('failed')
            return

        if not self.have_robot_pose:
            self.get_logger().error(
                'ยังไม่รู้ตำแหน่งรถตอนนี้เลย (TF map->base_link ยังไม่มา) -> '
                'เช็คว่า slam_toolbox / TF tree พร้อมหรือยัง'
            )
            self._publish_status('failed')
            return

        # --- เช็คที่ 1: ช่องที่จำไว้เก่าเกินไปหรือยัง ---
        target_time = Time.from_msg(self.target_pose.header.stamp)
        age_sec = (self.get_clock().now() - target_time).nanoseconds / 1e9
        if age_sec > self.target_max_age_sec:
            self.get_logger().error(
                f'ช่องจอดที่เจอไว้เก่าเกินไปแล้ว ({age_sec:.1f} วิ, เกิน '
                f'{self.target_max_age_sec:.1f} วิ) -> กรุณาขับผ่านช่องจอดใหม่แล้วกด B ทันที'
            )
            self._publish_status('failed')
            self.target_pose = None
            return

        # --- แปลง target_pose ไป frame 'map' ก่อน (Nav2 ทำงานใน map เป็นหลัก) ---
        # *** ใช้ transform "ล่าสุดที่สุด" (ไม่ใช่ transform ณ เวลาที่ตรวจเจอเสา) ***
        # พิกัดในเฟรม odom ของจุดจริงจุดหนึ่งไม่เคยเปลี่ยน (odom เป็นเฟรมต่อเนื่อง ไม่กระโดด)
        # สิ่งที่เปลี่ยนคือค่าประมาณ map<->odom ที่ slam_toolbox ปรับแก้ละเอียดอยู่ตลอดเวลา
        # (โดยเฉพาะช่วงที่แผนที่ยังไม่นิ่ง เห็นได้จาก costmap resize ถี่ ๆ) ถ้าย้อนไปใช้
        # transform ณ เวลาเก่า (ตอนตรวจเจอ) พิกัดที่แปลงออกมาจะอิงค่า map<->odom ที่ยังไม่ได้
        # รับการแก้ไขล่าสุด ทำให้เพี้ยนไปได้ไกลมาก (เจอเคสจริงเพี้ยนไป ~9-10 ม. ทั้งที่รถแทบ
        # ไม่ขยับ) วิธีแก้คือสร้างสำเนา pose เดิมแต่ตั้ง header.stamp = 0 (แปลว่า "เอา transform
        # ล่าสุดที่มี" ตามธรรมเนียมของ tf2) ก่อนส่งให้ tf2 แปลง
        goal_target = PoseStamped()
        goal_target.header.frame_id = self.target_pose.header.frame_id
        goal_target.header.stamp = Time().to_msg()  # 0 = ขอ transform ล่าสุดที่มีอยู่จริง
        goal_target.pose = self.target_pose.pose

        try:
            goal_pose = self.tf_buffer.transform(
                goal_target, 'map', timeout=self.tf_timeout
            )
        except Exception as e:
            self.get_logger().error(
                f'แปลง target_pose จาก frame "{self.target_pose.header.frame_id}" ไป '
                f'"map" ไม่สำเร็จ: {e}'
            )
            self._publish_status('failed')
            return

        # --- เช็คที่ 2: ตำแหน่งช่องที่จำไว้ห่างจากตำแหน่งรถตอนนี้ไกลเกินไปหรือยัง ---
        # (ทั้งคู่อยู่ frame 'map' แล้ว เทียบกันได้ตรง ๆ)
        dx = goal_pose.pose.position.x - self.robot_x
        dy = goal_pose.pose.position.y - self.robot_y
        distance = math.hypot(dx, dy)
        if distance > self.max_target_distance:
            self.get_logger().error(
                f'ตำแหน่งช่องจอดที่เจอไว้อยู่ห่างจากตำแหน่งรถตอนนี้ {distance:.2f} m '
                f'(เกิน {self.max_target_distance:.2f} m) -> รถขับห่างจากช่องไปมากแล้ว '
                f'กรุณาขับผ่านช่องจอดใหม่แล้วกด B ทันที'
            )
            self._publish_status('failed')
            self.target_pose = None
            return

        # --- เช็คที่ 3: Nav2 action server พร้อมไหม ---
        if not self._nav_client.wait_for_server(timeout_sec=self.nav2_server_wait_sec):
            self.get_logger().error(
                'ต่อ Nav2 action server (/navigate_to_pose) ไม่ได้ภายในเวลาที่กำหนด -> '
                'เช็คว่า Nav2 bring up ครบทุก node แล้วหรือยัง (bt_navigator ต้อง active, '
                'เช็คด้วย `ros2 lifecycle get /bt_navigator`)'
            )
            self._publish_status('failed')
            return

        # ใช้แล้วเคลียร์ทิ้งทันที (consume once) บังคับให้ต้องขับผ่านช่องใหม่ก่อนกด B รอบถัดไป
        self.target_pose = None

        self._goal_pose = goal_pose   # จำไว้ใช้รายงานผลตอนจอดสำเร็จ

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose

        self.state = self.NAVIGATING
        self._publish_status('in_progress')
        self.get_logger().info(
            f'เริ่มจอดอัตโนมัติผ่าน Nav2 -> เป้าหมาย x={goal_pose.pose.position.x:.2f}, '
            f'y={goal_pose.pose.position.y:.2f} (frame map, ระยะห่างจากรถตอนนี้ '
            f'{distance:.2f} m)'
        )

        send_goal_future = self._nav_client.send_goal_async(goal_msg)
        send_goal_future.add_done_callback(self._goal_response_cb)

    def _cancel_parking(self):
        if self.state == self.FINAL_REVERSE:
            self.get_logger().warn('ได้รับคำสั่ง cancel -> หยุดถอยปิดท้าย')
            self._finish_final_reverse('cancelled', 'cancelled')
            return
        if self.state == self.ALIGNING:
            self.get_logger().warn('ได้รับคำสั่ง cancel -> หยุดจัดตัวขนานกำแพง')
            self._finish_align('cancelled', 'cancelled', go_reverse=False)
            return
        if self.state == self.NAVIGATING and self._goal_handle is not None:
            self.get_logger().warn('ได้รับคำสั่ง cancel -> ยกเลิก Nav2 goal')
            cancel_future = self._goal_handle.cancel_goal_async()
            cancel_future.add_done_callback(self._cancel_done_cb)
        else:
            self.state = self.STOPPED
            self._publish_status('cancelled')

    def _cancel_done_cb(self, future):
        self.state = self.STOPPED
        self._goal_handle = None
        self._publish_status('cancelled')

    # ================================================================
    # NAV2 ACTION CALLBACKS
    # ================================================================
    def _goal_response_cb(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error(
                'Nav2 ปฏิเสธ goal นี้ (ไม่ accept) -> ตำแหน่งเป้าหมายอาจอยู่ในโซนที่ไป '
                'ไม่ถึง หรืออยู่ในสิ่งกีดขวางตาม costmap'
            )
            self.state = self.STOPPED
            self._publish_status('failed')
            return

        self._goal_handle = goal_handle
        result_future = goal_handle.get_result_async()
        result_future.add_done_callback(self._result_cb)

    def _result_cb(self, future):
        status = future.result().status
        self._goal_handle = None
        self.state = self.STOPPED

        if status == STATUS_SUCCEEDED:
            self.get_logger().info('จอดสำเร็จ! (Nav2 นำทางไปถึงเป้าหมายแล้ว)')
            if self.al_enable:
                # จัดตัวให้ขนานกำแพงก่อน (จบแล้วจะต่อถอยปิดท้ายเองถ้าเปิดไว้)
                self._start_align()
            elif self.fr_enable:
                # เลื่อนการประกาศ success ไปหลังขั้นถอยปิดท้าย (mode manager จะได้ไม่สลับกลับ
                # MANUAL และปิด velocity_smoother ก่อนถอยเสร็จ)
                self._start_final_reverse()
            else:
                self._publish_status('success')
        elif status == STATUS_CANCELED:
            self.get_logger().warn('Nav2 goal ถูกยกเลิก')
            self._publish_status('cancelled')
        else:
            self.get_logger().warn(f'จอดไม่สำเร็จ: Nav2 goal status={status} (aborted)')
            self._publish_status('failed')

    # ================================================================
    # FINAL REVERSE (ถอยตรงเข้าหากำแพง อ่านระยะจาก LiDAR ปิดลูปเอง)
    # ================================================================
    def _scan_cb(self, msg: LaserScan):
        self._last_scan = msg
        self._last_scan_rx = self.get_clock().now()

    def _rear_gap(self, scan: LaserScan):
        """ระยะจากกันชนท้ายถึงสิ่งกีดขวางด้านหลังตัวรถ (m) หรือ None ถ้าไม่เห็นอะไรเลย"""
        best = None
        a = scan.angle_min
        floor = self.fr_lidar_to_rear - 0.03   # จุดที่ใกล้กว่านี้ = ตัวรถเอง ไม่ใช่กำแพง
        for r in scan.ranges:
            if math.isfinite(r) and scan.range_min <= r <= scan.range_max:
                va = a - self.fr_lidar_yaw
                x = r * math.cos(va)     # + = หน้ารถ, - = หลังรถ
                y = r * math.sin(va)
                if x < 0.0 and abs(y) <= self.fr_half_width:
                    behind = -x
                    if behind >= floor and (best is None or behind < best):
                        best = behind
            a += scan.angle_increment
        return None if best is None else best - self.fr_lidar_to_rear

    def _front_gap(self, scan: LaserScan):
        """ระยะจากกันชนหน้าถึงสิ่งกีดขวางด้านหน้า (m) หรือ None ถ้าไม่เห็นอะไรเลย"""
        best = None
        a = scan.angle_min
        floor = self.fr_lidar_to_front - 0.03
        for r in scan.ranges:
            if math.isfinite(r) and scan.range_min <= r <= scan.range_max:
                va = a - self.fr_lidar_yaw
                x = r * math.cos(va)
                y = r * math.sin(va)
                if x > 0.0 and abs(y) <= self.fr_half_width:
                    if x >= floor and (best is None or x < best):
                        best = x
            a += scan.angle_increment
        return None if best is None else best - self.fr_lidar_to_front

    def _wall_angle_error(self, scan: LaserScan):
        """มุมที่รถต้องหมุน (rad, + = ทวนเข็ม) เพื่อให้แกนตัวรถขนานกำแพง หรือ None ถ้าวัดไม่ได้

        ใช้ทิศของเส้นตรงเล็ก ๆ ระหว่างจุด LiDAR ใกล้กัน แล้วเฉลี่ยในโดเมน 4*phi
        (กำแพงช่องตัวยูตั้งฉากกันเสมอ จึงได้มุมแบบ mod 90 deg โดยไม่ต้องรู้ว่ากำแพงไหนเป็นไหน)
        ผลลัพธ์อยู่ในช่วง +-45 deg
        """
        r_hi = min(scan.range_max, self.al_r_max)
        pts = []
        a = scan.angle_min
        for r in scan.ranges:
            if math.isfinite(r) and max(scan.range_min, self.al_r_min) <= r <= r_hi:
                va = a - self.fr_lidar_yaw
                pts.append((r * math.cos(va), r * math.sin(va)))
            else:
                pts.append(None)
            a += scan.angle_increment

        k = 3
        c = s = w = 0.0
        n = 0
        for i in range(len(pts) - k):
            p, q = pts[i], pts[i + k]
            if p is None or q is None:
                continue
            dx, dy = q[0] - p[0], q[1] - p[1]
            d = math.hypot(dx, dy)
            if d < 0.01 or d > 0.15:     # สั้นไป = noise, ยาวไป = กระโดดข้ามช่องว่าง/มุม
                continue
            phi = math.atan2(dy, dx)
            c += d * math.cos(4.0 * phi)
            s += d * math.sin(4.0 * phi)
            w += d
            n += 1
        if n < self.al_min_seg_n or w <= 0.0:
            return None
        if math.hypot(c, s) / w < self.al_min_coh:
            return None
        psi = math.atan2(s, c) / 4.0
        err = psi - self.al_ref
        # ห่อเข้าช่วง +-45 deg (เพราะกำแพงซ้ำทุก 90 deg)
        half = math.pi / 4.0
        while err > half:
            err -= math.pi / 2.0
        while err < -half:
            err += math.pi / 2.0
        return err

    # ================================================================
    # ALIGN (จัดตัวรถให้ขนานกำแพง: ถอย/เดินหน้าสลับ พร้อมเลี้ยวทิศเดียวกัน)
    # ================================================================
    # ยานยนต์ Ackermann: yaw_rate = v*tan(steer)/L ถ้าถอยแล้วเลี้ยวไปทางหนึ่ง
    # แล้วเดินหน้าด้วย "yaw rate เครื่องหมายเดิม" (steer สลับด้าน) รถจะหมุนไปทิศเดียวกัน
    # ทั้งสองช่วง ตำแหน่งแทบไม่เปลี่ยนสุทธิ (เหมือนกลับรถ 3 จังหวะ)
    def _start_align(self):
        self.state = self.ALIGNING
        now = self.get_clock().now()
        self._al_t0 = now
        self._al_phase = 'settle'
        self._al_phase_t0 = now
        self._al_legs = 0
        self._al_dir = 0
        self.get_logger().info(
            f'เริ่มจัดตัวขนานกำแพง (tol={math.degrees(self.al_tol):.1f} deg, '
            f'สูงสุด {self.al_max_legs} ช่วง ช่วงละ {self.al_leg_dist:.2f} m)'
        )
        self._al_timer = self.create_timer(0.05, self._align_step)

    def _align_step(self):
        now = self.get_clock().now()
        if (now - self._al_t0).nanoseconds / 1e9 > self.al_timeout:
            self._finish_align('success', 'หมดเวลาจัดตัว')
            return

        scan_ok = self._last_scan is not None and self._last_scan_rx is not None and \
            (now - self._last_scan_rx).nanoseconds / 1e9 <= self.fr_scan_max_age

        if self._al_phase == 'settle':
            self.pub_cmd.publish(Twist())
            if (now - self._al_phase_t0).nanoseconds / 1e9 < self.al_settle:
                return
            if not scan_ok:
                self._finish_align('success', 'ไม่มี scan สด')
                return
            err = self._wall_angle_error(self._last_scan)
            if err is None:
                self._finish_align('success', 'มองไม่เห็นกำแพงพอจะวัดมุม -> ไม่จัดตัว')
                return
            self.get_logger().info(
                f'จัดตัว: มุมคลาด {math.degrees(err):+.1f} deg (ช่วงที่ {self._al_legs})')
            if abs(err) <= self.al_tol:
                self._finish_align('success', f'ขนานแล้ว ({math.degrees(err):+.1f} deg)')
                return
            if self._al_legs >= self.al_max_legs:
                self._finish_align('success', f'ครบ {self.al_max_legs} ช่วงแล้ว '
                                   f'(เหลือคลาด {math.degrees(err):+.1f} deg)')
                return

            rear = self._rear_gap(self._last_scan)
            front = self._front_gap(self._last_scan)
            big = 9.9
            r_gap = big if rear is None else rear
            f_gap = big if front is None else front
            # สลับทิศทุกช่วง (ช่วงแรกเลือกด้านที่ว่างกว่า) ถ้าด้านที่ต้องไปไม่ว่างพอให้พลิก
            if self._al_dir == 0:
                want = -1 if r_gap >= f_gap else 1
            else:
                want = -self._al_dir
            if (want < 0 and r_gap <= self.al_min_clear) or \
                    (want > 0 and f_gap <= self.al_min_clear):
                want = -want
            if (want < 0 and r_gap <= self.al_min_clear) or \
                    (want > 0 and f_gap <= self.al_min_clear):
                self._finish_align('success', 'ที่แคบเกินไป ไม่มีระยะพอขยับ')
                return

            self._al_dir = want
            mag = max(self.al_w_min, min(self.al_w_max, self.al_w_gain * abs(err)))
            self._al_omega = math.copysign(mag, err)
            self._al_leg_start_xy = (self.robot_x, self.robot_y)
            self._al_phase = 'move'
            self._al_phase_t0 = now
            return

        # phase == 'move'
        leg_t = (now - self._al_phase_t0).nanoseconds / 1e9
        stop_reason = None
        if not scan_ok:
            stop_reason = 'no_scan'
        else:
            gap = self._rear_gap(self._last_scan) if self._al_dir < 0 \
                else self._front_gap(self._last_scan)
            if gap is not None and gap <= self.al_min_clear:
                stop_reason = 'clearance'
        travelled = math.hypot(self.robot_x - self._al_leg_start_xy[0],
                               self.robot_y - self._al_leg_start_xy[1])
        if stop_reason is None and travelled >= self.al_leg_dist:
            stop_reason = 'distance'
        if stop_reason is None and leg_t > 2.5:
            stop_reason = 'leg_timeout'

        if stop_reason is not None:
            for _ in range(3):
                self.pub_cmd.publish(Twist())
            self._al_legs += 1
            self._al_phase = 'settle'
            self._al_phase_t0 = now
            return

        cmd = Twist()
        cmd.linear.x = self._al_dir * self.al_speed
        cmd.angular.z = self._al_omega
        self.pub_cmd.publish(cmd)

    def _finish_align(self, status: str, reason: str, go_reverse: bool = True):
        if self._al_timer is not None:
            self._al_timer.cancel()
            self.destroy_timer(self._al_timer)
            self._al_timer = None
        for _ in range(3):
            self.pub_cmd.publish(Twist())
        self.get_logger().info(f'จบขั้นจัดตัวขนานกำแพง: {reason}')
        if go_reverse and self.fr_enable:
            self._start_final_reverse()
            return
        self.state = self.STOPPED
        self._publish_status(status)

    def _start_final_reverse(self):
        self.state = self.FINAL_REVERSE
        self._fr_start_time = self.get_clock().now()
        self._fr_start_xy = (self.robot_x, self.robot_y)
        self.get_logger().info(
            f'เริ่มถอยปิดท้าย: เป้าท้ายรถห่างกำแพง {self.fr_target_gap * 100:.0f} cm '
            f'(speed {self.fr_speed:.2f} m/s, ถอยได้ไม่เกิน {self.fr_max_dist:.2f} m)'
        )
        self._fr_timer = self.create_timer(0.05, self._final_reverse_step)

    def _final_reverse_step(self):
        now = self.get_clock().now()
        elapsed = (now - self._fr_start_time).nanoseconds / 1e9

        if self._last_scan is None or self._last_scan_rx is None or \
                (now - self._last_scan_rx).nanoseconds / 1e9 > self.fr_scan_max_age:
            self.get_logger().warn('ถอยปิดท้าย: ไม่มี scan สด -> หยุด')
            self._finish_final_reverse('success', 'no_scan')
            return

        gap = self._rear_gap(self._last_scan)
        if gap is None:
            self.get_logger().warn('ถอยปิดท้าย: ไม่เห็นสิ่งกีดขวางด้านหลัง -> ไม่ถอยต่อ')
            self._finish_final_reverse('success', 'no_wall')
            return

        travelled = math.hypot(self.robot_x - self._fr_start_xy[0],
                               self.robot_y - self._fr_start_xy[1])

        if gap <= self.fr_target_gap + self.fr_brake_margin:
            self._finish_final_reverse('success', f'ถึงระยะแล้ว (gap={gap * 100:.1f} cm)')
        elif travelled >= self.fr_max_dist:
            self._finish_final_reverse('success', f'ถอยครบระยะสูงสุดแล้ว (gap={gap * 100:.1f} cm)')
        elif elapsed >= self.fr_timeout:
            self._finish_final_reverse('success', f'หมดเวลา (gap={gap * 100:.1f} cm)')
        else:
            cmd = Twist()
            cmd.linear.x = -self.fr_speed
            if self.hh_enable:
                herr = self._wall_angle_error(self._last_scan)
                if herr is not None:
                    cmd.angular.z = max(-self.hh_max, min(self.hh_max, self.hh_gain * herr))
            self.pub_cmd.publish(cmd)

    def _finish_final_reverse(self, status: str, reason: str):
        if self._fr_timer is not None:
            self._fr_timer.cancel()
            self.destroy_timer(self._fr_timer)
            self._fr_timer = None
        for _ in range(3):
            self.pub_cmd.publish(Twist())   # สั่งหยุดซ้ำกันแพ็กเก็ตหาย
        self.state = self.STOPPED
        self.get_logger().info(f'จบขั้นถอยปิดท้าย: {reason}')
        self._publish_status(status)

    @staticmethod
    def _yaw_of(q):
        return math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                          1.0 - 2.0 * (q.y * q.y + q.z * q.z))

    def _report_final_pose(self):
        """log พิกัดเป้าหมายเทียบกับพิกัดสุดท้ายของรถ (frame map)"""
        if self._goal_pose is None:
            return
        try:
            t = self.tf_buffer.lookup_transform('map', 'base_link', Time())
        except Exception as e:
            self.get_logger().warn(f'อ่านตำแหน่งสุดท้ายไม่ได้: {e}')
            return

        tx = self._goal_pose.pose.position.x
        ty = self._goal_pose.pose.position.y
        tyaw = self._yaw_of(self._goal_pose.pose.orientation)
        fx = t.transform.translation.x
        fy = t.transform.translation.y
        fyaw = self._yaw_of(t.transform.rotation)

        err_xy = math.hypot(tx - fx, ty - fy)
        err_yaw = math.atan2(math.sin(tyaw - fyaw), math.cos(tyaw - fyaw))

        self.get_logger().info(
            '\n=== สรุปผลการจอด (frame map) ===\n'
            f'  พิกัดเป้าหมาย : x={tx:.3f} y={ty:.3f} yaw={math.degrees(tyaw):.1f} deg\n'
            f'  พิกัดสุดท้าย  : x={fx:.3f} y={fy:.3f} yaw={math.degrees(fyaw):.1f} deg\n'
            f'  คลาดเคลื่อน   : {err_xy * 100:.1f} cm, yaw {math.degrees(err_yaw):+.1f} deg'
        )
        self._goal_pose = None

    def _publish_status(self, status: str):
        if status == 'success':
            self._report_final_pose()
        msg = String()
        msg.data = status
        self.pub_status.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ParkingManeuver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
