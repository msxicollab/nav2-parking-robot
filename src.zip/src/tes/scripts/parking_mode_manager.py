#!/usr/bin/env python3
"""
parking_mode_manager.py

Node จัดการสลับโหมดระหว่างการขับแบบ manual (จอย) กับโหมดจอดอัตโนมัติ

การทำงาน:
  - ฟังปุ่ม B บน /joy (rising edge เท่านั้น กันการกดค้าง)
  - กด B ครั้งแรก (ตอนอยู่โหมด MANUAL) -> เข้าสู่โหมด PARKING
        publish /parking/command = "start"
  - กด B อีกครั้ง (ตอนอยู่โหมด PARKING) -> ยกเลิก กลับสู่ MANUAL ทันที
        publish /parking/command = "cancel"
  - ฟัง /parking/status จาก parking_maneuver.py:
        "success" หรือ "failed" -> สลับกลับสู่ MANUAL อัตโนมัติ (ไม่ต้องกดปุ่ม)

หมายเหตุเรื่องการสลับการควบคุมรถจริง:
  Node นี้ "ไม่" สั่ง cmd_vel เอง แต่ปล่อยให้ twist_mux เป็นคนเลือก
  ระหว่าง cmd_vel_manual (priority 100) กับ cmd_vel_auto (priority 10)
  ตามที่ตั้งไว้ใน twist_mux.yaml ดังนั้นตอน parking_maneuver เริ่ม publish
  /cmd_vel_auto รถจะถูกยึดคุมอัตโนมัติ (เมื่อ manual ไม่ได้ publish อยู่)
  และพอ parking_maneuver หยุด publish (จบงาน/cancel) รถจะกลับไปฟัง joy เอง
  (timeout 0.5s ตาม config)

หมายเหตุเรื่อง velocity_smoother lifecycle:
  velocity_smoother ถูกแยกไปอยู่ lifecycle_manager ของตัวเอง
  (ชื่อ lifecycle_manager_smoother, autostart=False -- ดู car1_core.launch.py
  หัวข้อ 9.5) โดยตั้งใจไม่ให้ autostart ตอน core launch เพราะถ้า active
  ตลอดเวลาจะ publish /cmd_vel_auto ค้างแม้ค่าเป็น 0 นิ่งๆ ก็ตาม
  Node นี้จึงเป็นคน configure+activate ตอนเข้าโหมด PARKING (_enter_parking)
  และ deactivate+cleanup ตอนกลับสู่โหมด MANUAL ไม่ว่าจะมาจากการกดยกเลิก
  (_cancel_parking) หรือจบงานเอง (_enter_manual จาก status_cb)

Publish:
  /parking/command   (std_msgs/String)  "start" | "cancel"
  /parking/active    (std_msgs/Bool)    true = อยู่ในโหมดจอดอัตโนมัติ

Subscribe:
  /joy               (sensor_msgs/Joy)
  /parking/status    (std_msgs/String)  "in_progress" | "success" | "failed" | "cancelled"

Service Client:
  /lifecycle_manager_smoother/manage_nodes  (nav2_msgs/srv/ManageLifecycleNodes)
"""

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Joy
from std_msgs.msg import String, Bool
from nav2_msgs.srv import ManageLifecycleNodes


class ParkingModeManager(Node):

    STATE_MANUAL = 'MANUAL'
    STATE_PARKING = 'PARKING'

    def __init__(self):
        super().__init__('parking_mode_manager')

        # ============================================================
        # PARAMETERS
        # ============================================================
        # ปุ่ม B บนจอยมาตรฐาน Xbox/DualShock ผ่าน joy_node มักเป็น index 1
        # ถ้าจอยรุ่นอื่น mapping ต่างออกไป ปรับผ่าน parameter ได้เลย
        self.declare_parameter('button_toggle', 1)

        self.button_toggle = int(self.get_parameter('button_toggle').value)

        # ============================================================
        # STATE
        # ============================================================
        self.state = self.STATE_MANUAL
        self.prev_button = 0

        # ============================================================
        # PUBLISHERS
        # ============================================================
        self.pub_command = self.create_publisher(String, '/parking/command', 10)
        self.pub_active = self.create_publisher(Bool, '/parking/active', 10)

        # ============================================================
        # SUBSCRIBERS
        # ============================================================
        self.sub_joy = self.create_subscription(Joy, '/joy', self.joy_cb, 10)
        self.sub_status = self.create_subscription(String, '/parking/status', self.status_cb, 10)

        # ============================================================
        # SERVICE CLIENT -- velocity_smoother lifecycle
        # ============================================================
        # เรียก service ของ lifecycle_manager_smoother (ดูหมายเหตุด้านบน)
        # ใช้ async call_async() เสมอ ห้ามใช้ call() แบบ blocking เพราะจะ
        # ค้าง executor ทั้ง node (spin ครั้งเดียว, ไม่มี callback group แยก)
        self.cli_smoother = self.create_client(
            ManageLifecycleNodes, '/lifecycle_manager_smoother/manage_nodes'
        )

        # publish สถานะเริ่มต้นให้ node อื่นรู้
        self._publish_active()

        self.get_logger().info(
            f'parking_mode_manager started (toggle button index = {self.button_toggle}, '
            f'state = {self.state})'
        )

    # ================================================================
    # JOY CALLBACK
    # ================================================================
    def joy_cb(self, msg: Joy):
        if len(msg.buttons) <= self.button_toggle:
            return

        btn = msg.buttons[self.button_toggle]

        # rising edge เท่านั้น: 0 -> 1
        if btn == 1 and self.prev_button == 0:
            self._on_button_pressed()

        self.prev_button = btn

    def _on_button_pressed(self):
        if self.state == self.STATE_MANUAL:
            self._enter_parking()
        else:
            self._cancel_parking()

    # ================================================================
    # PARKING STATUS CALLBACK (จาก parking_maneuver.py)
    # ================================================================
    def status_cb(self, msg: String):
        status = msg.data

        if status in ('success', 'failed'):
            if self.state == self.STATE_PARKING:
                if status == 'success':
                    self.get_logger().info('จอดสำเร็จ -> สลับกลับสู่โหมด MANUAL อัตโนมัติ')
                else:
                    self.get_logger().warn('จอดไม่สำเร็จ -> สลับกลับสู่โหมด MANUAL อัตโนมัติ')
                self._enter_manual()
        # "cancelled" ไม่ต้องทำอะไรเพิ่ม เพราะ mode_manager เป็นคนสั่ง cancel เองอยู่แล้ว

    # ================================================================
    # VELOCITY_SMOOTHER LIFECYCLE HELPERS
    # ================================================================
    def _call_smoother_lifecycle(self, command: int, label: str):
        """เรียก ManageLifecycleNodes แบบ async ไปที่ lifecycle_manager_smoother

        command: ManageLifecycleNodes.Request.STARTUP หรือ .RESET
                 (STARTUP = configure+activate ครบชุด, RESET = deactivate+cleanup)
        label:   ข้อความสำหรับ log เท่านั้น
        """
        if not self.cli_smoother.service_is_ready():
            self.get_logger().warn(
                f'lifecycle_manager_smoother service ยังไม่พร้อม -- ข้าม {label} '
                f'(velocity_smoother อาจไม่ activate/deactivate ตามที่ต้องการ)'
            )
            return

        req = ManageLifecycleNodes.Request()
        req.command = command
        future = self.cli_smoother.call_async(req)
        future.add_done_callback(
            lambda f, label=label: self._smoother_lifecycle_done_cb(f, label)
        )

    def _smoother_lifecycle_done_cb(self, future, label: str):
        try:
            response = future.result()
        except Exception as exc:
            self.get_logger().error(f'{label} ล้มเหลว: {exc}')
            return

        if response.success:
            self.get_logger().info(f'{label} สำเร็จ (velocity_smoother)')
        else:
            self.get_logger().error(f'{label} ล้มเหลว (velocity_smoother ตอบ success=False)')

    def _activate_smoother(self):
        self._call_smoother_lifecycle(
            ManageLifecycleNodes.Request.STARTUP, 'configure+activate'
        )

    def _deactivate_smoother(self):
        self._call_smoother_lifecycle(
            ManageLifecycleNodes.Request.RESET, 'deactivate+cleanup'
        )

    # ================================================================
    # STATE TRANSITIONS
    # ================================================================
    def _enter_parking(self):
        self.state = self.STATE_PARKING
        self._publish_active()
        self._activate_smoother()

        cmd = String()
        cmd.data = 'start'
        self.pub_command.publish(cmd)

        self.get_logger().info('กดปุ่ม B -> เริ่มโหมดจอดอัตโนมัติ')

    def _cancel_parking(self):
        self.state = self.STATE_MANUAL
        self._publish_active()
        self._deactivate_smoother()

        cmd = String()
        cmd.data = 'cancel'
        self.pub_command.publish(cmd)

        self.get_logger().warn('กดปุ่ม B ซ้ำ -> ยกเลิกโหมดจอดอัตโนมัติ กลับสู่ MANUAL')

    def _enter_manual(self):
        self.state = self.STATE_MANUAL
        self._publish_active()
        self._deactivate_smoother()

    def _publish_active(self):
        msg = Bool()
        msg.data = (self.state == self.STATE_PARKING)
        self.pub_active.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ParkingModeManager()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
