#!/usr/bin/env python3

"""
joy_to_cmd_vel.py

รับ sensor_msgs/Joy จาก joy_node
แล้วแปลงเป็น geometry_msgs/Twist บน /cmd_vel_manual

Mapping:
  - เดินหน้า:
      LT (Left Trigger) -> axes[2]
      ไม่กด = 1.0, กดสุด = -1.0

  - ถอยหลัง:
      RT (Right Trigger) -> axes[5]
      ไม่กด = 1.0, กดสุด = -1.0

  - เลี้ยวซ้าย / ขวา:
      สติ๊กขวา แกนนอน -> axes[3]

  - ไม่มีปุ่ม deadman:
      โยกสติ๊กแล้วรถเคลื่อนที่ทันที

  - Watchdog:
      ถ้าไม่มี /joy ใหม่เกิน joy_timeout วินาที
      จะส่งคำสั่งหยุดอัตโนมัติ

Output:
  /cmd_vel_manual
  geometry_msgs/msg/Twist

ออกแบบให้ตรงกับ twist_mux ที่รับ:
  /cmd_vel_manual -> Twist
"""


import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist


class JoyToCmdVel(Node):

    def __init__(self):
        super().__init__('joy_to_cmd_vel')

        # ============================================================
        # PARAMETERS
        # ============================================================

        # LT = เดินหน้า (axes[2])
        self.declare_parameter(
            'axis_lt',
            2
        )

        # RT = ถอยหลัง (axes[5])
        self.declare_parameter(
            'axis_rt',
            5
        )

        self.declare_parameter(
            'axis_angular',
            3
        )

        self.declare_parameter(
            'button_estop',
            9
        )

        self.declare_parameter(
            'stick_deadzone',
            0.05
        )

        self.declare_parameter(
            'joy_timeout',
            0.5
        )

        # กลับทิศเดินหน้า/ถอยหลัง
        self.declare_parameter(
            'linear_scale',
            0.5
        )

        # กลับทิศเลี้ยวซ้าย/ขวา
        self.declare_parameter(
            'angular_scale',
            1.0
        )

        # expo/cubic curve: 0.0 = linear ล้วน, 1.0 = cubic ล้วน
        # ค่ายิ่งสูง ช่วงกดเบาๆ จะยิ่งนุ่มนวล/ตอบสนองช้าลง แต่กดสุด
        # ยังไปถึง max เท่าเดิม (ช่วยควบคุมละเอียดตอนซ้อมจอด)
        self.declare_parameter(
            'linear_expo',
            0.5
        )

        self.declare_parameter(
            'angular_expo',
            0.5
        )

        # v2: เพิ่มจาก 20.0 -> 30.0 Hz — ให้ margin มากขึ้นก่อนจะชน
        # twist_mux "manual" timeout (0.5s ใน twist_mux.yaml) หรือ ESP32
        # safety timeout (300ms) เผื่อ CPU jitter บน PC (nav2, slam, rviz
        # รันพร้อมกันหนัก) หรือ WiFi congestion ทำให้บาง tick มาช้า/หายไป
        # *** นี่เป็นแค่ mitigation ไม่ใช่ root cause fix — ต้นตอที่แท้จริง
        # ต้องตรวจด้วย `ros2 topic hz /cmd_vel_manual` กับ `/cmd_vel` ระหว่าง
        # โยกจอยเดินหน้าค้างจริงๆ ว่าอัตราตกที่จุดไหน (node นี้ / twist_mux /
        # WiFi ไป ESP32) ***
        self.declare_parameter(
            'publish_rate',
            30.0
        )

        # ============================================================
        # LOAD PARAMETERS
        # ============================================================

        self.axis_lt = int(
            self.get_parameter('axis_lt').value
        )

        self.axis_rt = int(
            self.get_parameter('axis_rt').value
        )

        self.axis_angular = int(
            self.get_parameter('axis_angular').value
        )

        self.button_estop = int(
            self.get_parameter('button_estop').value
        )

        self.stick_deadzone = float(
            self.get_parameter('stick_deadzone').value
        )

        self.joy_timeout = float(
            self.get_parameter('joy_timeout').value
        )

        self.linear_scale = float(
            self.get_parameter('linear_scale').value
        )

        self.angular_scale = float(
            self.get_parameter('angular_scale').value
        )

        self.linear_expo = float(
            self.get_parameter('linear_expo').value
        )

        self.angular_expo = float(
            self.get_parameter('angular_expo').value
        )

        rate = float(
            self.get_parameter('publish_rate').value
        )

        # ============================================================
        # STATE
        # ============================================================

        self.last_joy = None
        self.last_joy_time = None

        # E-stop state
        self.estop_active = False

        # ใช้ตรวจ rising edge ของปุ่ม L3
        self.prev_estop_btn = 0

        # ============================================================
        # DEBUG LOGGING STATE (เพิ่มใหม่)
        #
        # เป้าหมาย: แยกให้ชัดว่าอาการกระตุกมาจาก node นี้เองหรือไม่ โดยจับ
        # เวลาจริงระหว่างแต่ละครั้งที่ publish_cmd() ทำงาน (ควรจะสม่ำเสมอที่
        # 1/publish_rate วินาทีเป๊ะๆ เพราะผูกกับ ROS timer ไม่ใช่ joy callback
        # อยู่แล้ว) ถ้า interval นี้เพี้ยนไปจากที่ควร แปลว่าปัญหาเริ่มจาก PC
        # ฝั่งนี้ ไม่ใช่ ESP32/WiFi
        # ============================================================

        self.last_publish_time = None
        self.publish_period_s = 1.0 / rate

        # แจ้งเตือนถ้า interval ระหว่าง publish ห่างเกิน 2 เท่าของที่ควรจะเป็น
        self.publish_gap_warn_threshold_s = self.publish_period_s * 2.0

        # นับจำนวนครั้งที่ publish เพื่อ log สรุปเป็นช่วงๆ แทนที่จะ log ทุกครั้ง
        self.publish_count = 0

        # log สรุปทุกๆ กี่วินาที (ไม่ log ทุก tick เพราะจะ spam ที่ 30Hz)
        self.summary_log_interval_s = 2.0
        self.last_summary_log_time = None

        # เก็บค่า max gap ที่เจอในช่วง summary window ปัจจุบัน เพื่อโชว์ตอนสรุป
        self.max_gap_in_window_s = 0.0

        # นับจำนวนครั้งที่ watchdog timeout ทำงาน (สลับ state) เพื่อ log
        # ตอน edge เท่านั้น ไม่ log ซ้ำทุก tick ระหว่างที่ timeout ค้างอยู่
        self.was_in_watchdog_timeout = False

        # ============================================================
        # ROS SUBSCRIBER
        # ============================================================

        self.sub = self.create_subscription(
            Joy,
            '/joy',
            self.joy_cb,
            10
        )

        # ============================================================
        # ROS PUBLISHER
        #
        # สำคัญ:
        # twist_mux ของคุณรับ Twist (use_stamped: false)
        # ============================================================

        self.pub = self.create_publisher(
            Twist,
            '/cmd_vel_manual',
            10
        )

        # ============================================================
        # TIMER
        # ============================================================

        self.timer = self.create_timer(
            1.0 / rate,
            self.publish_cmd
        )

        # ============================================================
        # LOG
        # ============================================================

        self.get_logger().info(
            '=================================================='
        )

        self.get_logger().info(
            'joy_to_cmd_vel started'
        )

        self.get_logger().info(
            f'LT axis (forward) = {self.axis_lt}'
        )

        self.get_logger().info(
            f'RT axis (reverse) = {self.axis_rt}'
        )

        self.get_logger().info(
            f'angular axis = {self.axis_angular}'
        )

        self.get_logger().info(
            f'E-stop button = {self.button_estop}'
        )

        self.get_logger().info(
            f'deadzone = {self.stick_deadzone}'
        )

        self.get_logger().info(
            f'joy timeout = {self.joy_timeout}s'
        )

        self.get_logger().info(
            f'linear scale = {self.linear_scale}'
        )

        self.get_logger().info(
            f'angular scale = {self.angular_scale}'
        )

        self.get_logger().info(
            f'linear expo = {self.linear_expo}'
        )

        self.get_logger().info(
            f'angular expo = {self.angular_expo}'
        )

        self.get_logger().info(
            f'publish rate = {rate} Hz'
        )

        self.get_logger().info(
            'output: /cmd_vel_manual -> Twist'
        )

        self.get_logger().info(
            f'[DEBUG] publish gap warn threshold = '
            f'{self.publish_gap_warn_threshold_s * 1000:.1f} ms '
            f'(2x expected period)'
        )

        self.get_logger().info(
            f'[DEBUG] summary log every '
            f'{self.summary_log_interval_s}s'
        )

        self.get_logger().info(
            '=================================================='
        )

    # ================================================================
    # JOY CALLBACK
    # ================================================================

    def joy_cb(self, msg: Joy):

        # เก็บข้อมูล joystick ล่าสุด
        self.last_joy = msg

        # เวลาที่ได้รับ /joy ล่าสุด
        self.last_joy_time = self.get_clock().now()

        # ------------------------------------------------------------
        # E-STOP BUTTON
        # ------------------------------------------------------------

        if len(msg.buttons) > self.button_estop:

            btn = msg.buttons[self.button_estop]

            # Rising edge:
            # 0 -> 1 เท่านั้นถึงจะสลับสถานะ
            if btn == 1 and self.prev_estop_btn == 0:

                self.estop_active = not self.estop_active

                if self.estop_active:

                    self.get_logger().warn(
                        'L3 PRESSED -> E-STOP ACTIVE'
                    )

                else:

                    self.get_logger().info(
                        'L3 PRESSED -> E-STOP RELEASED'
                    )

            self.prev_estop_btn = btn

    # ================================================================
    # DEADZONE
    # ================================================================

    def _apply_deadzone(self, value: float) -> float:

        if abs(value) < self.stick_deadzone:
            return 0.0

        return value

    # ================================================================
    # EXPO / CUBIC CURVE
    #
    # ทำให้ช่วงกดเบาๆ ตอบสนองช้าลง (นุ่มนวล ควบคุมละเอียดได้) แต่กดสุด
    # ยังไปถึง 1.0 (เพดานเดิม) เหมือนเดิม — ค่า expo คือสัดส่วนของ cubic
    # เทียบกับ linear (0.0 = เชิงเส้นล้วน, 1.0 = cubic ล้วน)
    # สูตรเดียวกับที่ใช้ใน joy_to_cmd.cpp: expo*x^3 + (1-expo)*x
    # ================================================================

    def _apply_expo(self, value: float, expo: float) -> float:

        return expo * (value ** 3) + (1.0 - expo) * value

    # ================================================================
    # PUBLISH COMMAND
    # ================================================================

    def publish_cmd(self):

        # ------------------------------------------------------------
        # สร้าง Twist ทุกครั้ง
        # ------------------------------------------------------------

        msg = Twist()

        # shortcut (ให้โค้ดด้านล่างที่อ้างถึง twist.* ยังใช้ได้เหมือนเดิม)
        twist = msg

        # ------------------------------------------------------------
        # ยังไม่มี /joy
        # ------------------------------------------------------------

        if self.last_joy is None:

            # ส่งหยุด
            self._debug_track_publish_timing()
            self.pub.publish(msg)

            return

        # ------------------------------------------------------------
        # WATCHDOG
        # ------------------------------------------------------------

        elapsed = (
            self.get_clock().now()
            - self.last_joy_time
        ).nanoseconds / 1e9

        if elapsed > self.joy_timeout:

            # ไม่มี /joy นานเกินกำหนด
            # สั่งหยุดทันที

            # [DEBUG] log ตอน edge เข้า watchdog timeout เท่านั้น (ไม่ log
            # ซ้ำทุก tick ระหว่างที่ค้างอยู่ในสภาวะนี้) เพื่อดูว่า /joy
            # ขาดหายจริงหรือไม่ตอนที่สงสัยว่ากระตุก
            if not self.was_in_watchdog_timeout:
                self.get_logger().warn(
                    f'[DEBUG] /joy watchdog TIMEOUT triggered — '
                    f'no /joy for {elapsed:.3f}s '
                    f'(limit={self.joy_timeout}s) — sending stop'
                )
                self.was_in_watchdog_timeout = True

            twist.linear.x = 0.0
            twist.linear.y = 0.0
            twist.linear.z = 0.0

            twist.angular.x = 0.0
            twist.angular.y = 0.0
            twist.angular.z = 0.0

            self._debug_track_publish_timing()
            self.pub.publish(msg)

            return

        # [DEBUG] ถ้าเพิ่งพ้นสภาวะ watchdog timeout กลับมามี /joy ปกติ
        # ให้ log edge ขาออกด้วย
        if self.was_in_watchdog_timeout:
            self.get_logger().info(
                '[DEBUG] /joy watchdog timeout CLEARED — /joy resumed'
            )
            self.was_in_watchdog_timeout = False

        # ------------------------------------------------------------
        # E-STOP
        # ------------------------------------------------------------

        if self.estop_active:

            # ทุกค่าต้องเป็น 0

            twist.linear.x = 0.0
            twist.linear.y = 0.0
            twist.linear.z = 0.0

            twist.angular.x = 0.0
            twist.angular.y = 0.0
            twist.angular.z = 0.0

            self._debug_track_publish_timing()
            self.pub.publish(msg)

            return

        # ------------------------------------------------------------
        # JOYSTICK DATA
        # ------------------------------------------------------------

        j = self.last_joy

        # ------------------------------------------------------------
        # LINEAR (LT = เดินหน้า, RT = ถอยหลัง)
        #
        # Trigger ดิบ: ไม่กด = 1.0, กดสุด = -1.0
        # แปลงเป็นระดับความแรง 0.0 (ไม่กด) -> 1.0 (กดสุด)
        # ด้วยสูตร: (1.0 - raw) / 2.0
        # ------------------------------------------------------------

        lt_amount = 0.0
        rt_amount = 0.0

        if len(j.axes) > self.axis_lt:
            lt_raw = j.axes[self.axis_lt]
            lt_amount = self._apply_deadzone(
                (1.0 - lt_raw) / 2.0
            )
            lt_amount = self._apply_expo(
                lt_amount, self.linear_expo
            )

        if len(j.axes) > self.axis_rt:
            rt_raw = j.axes[self.axis_rt]
            rt_amount = self._apply_deadzone(
                (1.0 - rt_raw) / 2.0
            )
            rt_amount = self._apply_expo(
                rt_amount, self.linear_expo
            )

        # LT เดินหน้า (+), RT ถอยหลัง (-)
        # ถ้ากดพร้อมกันทั้งคู่ จะหักล้างกันเอง
        lin = lt_amount - rt_amount

        twist.linear.x = (
            lin * self.linear_scale
        )

        # ------------------------------------------------------------
        # ANGULAR
        #
        # Right stick X -> axes[3]
        # ------------------------------------------------------------

        if len(j.axes) > self.axis_angular:

            ang = self._apply_deadzone(
                j.axes[self.axis_angular]
            )
            ang = self._apply_expo(
                ang, self.angular_expo
            )

            twist.angular.z = (
                ang * self.angular_scale
            )

        else:

            twist.angular.z = 0.0

        # ------------------------------------------------------------
        # PUBLISH
        # ------------------------------------------------------------

        self._debug_track_publish_timing()
        self.pub.publish(msg)

    # ================================================================
    # [DEBUG] PUBLISH TIMING TRACKER
    #
    # เรียกจากทุกจุดที่ publish_cmd() ทำการ publish จริง (ทุก early-return
    # branch รวมถึง path ปกติ) เพื่อวัด interval ระหว่างการ publish แต่ละ
    # ครั้งจริงๆ — ถ้า node นี้เองมี jitter/gap ผิดปกติ จะเห็นตรงนี้ก่อน
    # ที่จะไปโทษ ESP32/WiFi
    # ================================================================

    def _debug_track_publish_timing(self):

        now = self.get_clock().now()
        self.publish_count += 1

        if self.last_publish_time is not None:

            gap_s = (
                now - self.last_publish_time
            ).nanoseconds / 1e9

            if gap_s > self.max_gap_in_window_s:
                self.max_gap_in_window_s = gap_s

            # เตือนทันทีถ้า gap เกิน threshold (2x expected period) —
            # นี่คือสัญญาณว่า node นี้เองหน่วง ไม่ใช่ปัญหาปลายทาง
            if gap_s > self.publish_gap_warn_threshold_s:
                self.get_logger().warn(
                    f'[DEBUG] publish gap = {gap_s * 1000:.1f} ms '
                    f'(expected ~{self.publish_period_s * 1000:.1f} ms) '
                    f'— this node itself is late, not ESP32/WiFi'
                )

        self.last_publish_time = now

        # log สรุปเป็นช่วงๆ (ทุก summary_log_interval_s วินาที) แทนที่จะ
        # log ทุก tick ซึ่งจะรก log ที่ 30Hz เกินไป
        if self.last_summary_log_time is None:
            self.last_summary_log_time = now
            return

        since_summary_s = (
            now - self.last_summary_log_time
        ).nanoseconds / 1e9

        if since_summary_s >= self.summary_log_interval_s:

            actual_rate_hz = (
                self.publish_count / since_summary_s
                if since_summary_s > 0 else 0.0
            )

            self.get_logger().info(
                f'[DEBUG] publish_count={self.publish_count} '
                f'actual_rate={actual_rate_hz:.1f}Hz '
                f'max_gap={self.max_gap_in_window_s * 1000:.1f}ms '
                f'(window={since_summary_s:.1f}s)'
            )

            self.publish_count = 0
            self.max_gap_in_window_s = 0.0
            self.last_summary_log_time = now


# ====================================================================
# MAIN
# ====================================================================

def main(args=None):

    rclpy.init(args=args)

    node = JoyToCmdVel()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    finally:

        # ส่ง STOP ก่อนปิด node
        try:

            stop_msg = Twist()

            stop_msg.linear.x = 0.0
            stop_msg.linear.y = 0.0
            stop_msg.linear.z = 0.0

            stop_msg.angular.x = 0.0
            stop_msg.angular.y = 0.0
            stop_msg.angular.z = 0.0

            node.pub.publish(stop_msg)

        except Exception:

            pass

        node.destroy_node()

        rclpy.shutdown()


if __name__ == '__main__':
    main()
