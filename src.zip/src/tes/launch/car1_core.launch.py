#!/usr/bin/env python3
"""
car1_core.launch.py
======================
ไฟล์หลัก (core) — เปิดทิ้งไว้ตลอดทั้ง session เดียว ไม่ต้องปิด-เปิดใหม่ระหว่างทดสอบ

รวม:
  1) micro-ROS agent
  2) robot_state_publisher + joint_state_publisher
  3) ไม่รัน odom_to_tf.py — ให้ ekf_filter_node เป็นผู้ publish odom → base_link เพียงตัวเดียว
  3.05) scan_filter (laser_filters) -> publish /scan_filtered
  3.1) ekf_filter_node (robot_localization)
  3.2) odom_bridge.py
     *** ย้ายเข้ามาอยู่ใน core ***
     แปลง /odom_lite (car1_msgs/OdomLite, จาก ESP32) เป็น /odom มาตรฐาน
     (nav_msgs/Odometry) ให้ ekf_filter_node ใช้ subscribe แบบ BEST_EFFORT QoS
     เพื่อให้ตรงกับ publisher ฝั่ง ESP32
  3.3) udp_cmd_bridge.py
     *** ย้ายเข้ามาอยู่ใน core (เดิมอยู่ car1_manual_control.launch.py) ***
     ส่ง /cmd_vel (ผลลัพธ์สุดท้ายจาก twist_mux) เป็น raw UDP ไปยัง ESP32
     โดยตรง ต้องอยู่ใน core เพราะต้องพร้อมรับ /cmd_vel ไม่ว่าจะมาจาก manual
     หรือ auto-park ก็ตาม (twist_mux เป็นคนตัดสินใจแล้วว่าจะให้สัญญาณไหนออก)
     esp32_ip hardcode ไว้ที่ตัวแปร ESP32_IP ด้านล่าง แก้ตรงนี้ที่เดียว
  4) joy_node
     *** สำคัญ: อยู่ใน core เสมอ ห้ามย้ายไปไฟล์ node บังคับ ***
     เพราะ parking_mode_manager.py (อยู่คนละไฟล์ car1_parking_auto.launch.py)
     ฟังปุ่ม B จาก /joy โดยตรง ถ้าปิด joy_node ไปพร้อมกับ node บังคับตอนถึง
     waypoint แล้ว จะไม่มี /joy topic ให้กดปุ่ม B สั่งเริ่มจอดอัตโนมัติได้เลย
     ส่วน joy_to_cmd_vel.py (ตัวแปลงแกน joystick -> cmd_vel_manual) เท่านั้น
     ที่แยกไปอยู่ car1_manual_control.launch.py และปิดได้เองเมื่อถึง waypoint
  7) twist_mux
     อยู่ใน core เสมอ เพราะต้องพร้อมรับทั้ง cmd_vel_manual (จาก manual control
     launch) และ cmd_vel_auto (จาก parking auto launch) ไม่ว่าจะเปิดฝั่งไหนอยู่
     *** cmd_vel_recovery (จาก behavior_server) เข้าทาง twist_mux ด้วยเช่นกัน
     ดู twist_mux.yaml ที่เพิ่ม topic "recovery" priority สูงสุด (150) ไว้แล้ว ***
  8) slam_toolbox (async) + lifecycle_manager_slam
  9) Nav2 stack (controller/planner/behavior/bt_navigator)
     + lifecycle_manager_navigation
     *** smoother_server ปิดไว้แล้ว (ไม่ถูกใช้จริงโดย BT XML ปัจจุบัน,
     SmacPlannerHybrid สมูทเส้นทางในตัวเองอยู่แล้ว) ***
     *** behavior_server remap cmd_vel -> cmd_vel_recovery ***
     เดิม behavior_server (spin/backup/drive_on_heading/wait) publish ตรงไปที่
     /cmd_vel โดยไม่ผ่าน twist_mux เลย ชนกับ output ของ twist_mux เอง
     (ยืนยันจาก `ros2 topic info /cmd_vel -v` เจอ Publisher count: 5 —
     twist_mux 1 ตัว + behavior_server 4 ตัว จาก action ต่างกัน) ทำให้ตอน
     recovery ทำงาน (เช่น backup) คำสั่งความเร็วโดนแทรก/ชนกับสัญญาณอื่นเป็น
     ระยะ ๆ ไม่มี priority arbitration ใด ๆ เลย ขยับเป็น remap ออกไปที่
     cmd_vel_recovery แล้วให้ twist_mux เป็นคนรวมสัญญาณแทน (ดู twist_mux.yaml)
  9.5) velocity_smoother -- *** แยก lifecycle_manager ของตัวเอง, autostart=False ***
     เดิม velocity_smoother อยู่ใน lifecycle_manager_navigation ตัวเดียวกับ
     controller/planner/behavior/bt_navigator ที่ autostart=True ทำให้มันถูก
     configure+activate อัตโนมัติทันทีตอน launch แม้ยังไม่มีใครสั่ง navigate เลย
     เมื่อ active แล้ว nav2_velocity_smoother จะ publish cmd_vel_smoothed
     (remap เป็น /cmd_vel_auto) ต่อเนื่องตลอดเวลาแม้ค่าเป็น 0 นิ่งๆ ก็ตาม —
     twist_mux เห็น /cmd_vel_auto (priority 100) กำลัง publish อยู่ตลอด เลย
     เลือกมันชนะ /cmd_vel_manual (priority 10) ทุกครั้ง ทำให้กดจอยเดินหน้า
     ยังไงก็ไม่ขยับ (รถ "กระตุก" เป็นช่วงสั้นๆ เฉพาะจังหวะที่ smoother หยุด
     publish ชั่วขณะจน timeout 0.5s ของ auto_park topic หมดอายุพอดี)
     แก้โดยแยก velocity_smoother ไปอยู่ lifecycle_manager ของตัวเอง (ชื่อ
     lifecycle_manager_smoother) และ "ไม่" ตั้ง autostart=True ให้มัน — จะยังไม่
     ถูก configure/activate จนกว่าจะมีคน call service เอง (ให้
     car1_parking_auto.launch.py หรือ parking_mode_manager.py เป็นคน
     configure+activate ตอนเริ่มโหมด PARKING จริงๆ เท่านั้น)
  10) rviz2

ไม่รวม (แยกไปไฟล์อื่น เปิด/ปิดเองตามจังหวะ):
  - joy_to_cmd_vel.py                 -> car1_manual_control.launch.py
  - parking_spot_detector.py          -> car1_parking_detector.launch.py
  - parking_mode_manager.py           -> car1_parking_auto.launch.py
  - parking_maneuver.py               -> car1_parking_auto.launch.py

*** หมายเหตุสำคัญเกี่ยวกับ car1_manual_control.launch.py ***
udp_cmd_bridge.py ถูกย้ายมาอยู่ใน core.launch.py นี้แล้ว ถ้า
car1_manual_control.launch.py เวอร์ชันเก่ายังมี udp_cmd_bridge.py อยู่ด้วย
ต้องลบออกจากไฟล์นั้นก่อน ไม่งั้นจะมี node ชื่อซ้ำ (udp_cmd_bridge) รันพร้อมกัน
2 ตัว แย่งกันส่ง UDP ไปที่ ESP32 ตัวเดียวกัน (ผู้ใช้แจ้งว่าจะยังไม่ลบไฟล์เก่า
ทันที เพราะ car1_manual_control.launch.py เวอร์ชันเดิมยังใช้งานอยู่ก่อน
อัปโหลดเวอร์ชันใหม่ — อย่ารัน core.launch.py นี้กับ manual_control.launch.py
เวอร์ชันเก่าพร้อมกันสองไฟล์)

วิธีรัน (terminal ที่ 1 เปิดทิ้งไว้ตลอด):
  source /opt/ros/jazzy/setup.bash
  source ~/ros2_ws/install/setup.bash
  ros2 launch /home/msxi/ros2_ws/src/tes/launch/car1_core.launch.py

*** สำคัญ: velocity_smoother ตอนนี้ไม่ auto-activate แล้ว ***
ก่อนใช้งานโหมด auto-park ครั้งแรกในแต่ละ session ต้อง activate มันเองครั้งเดียว
ด้วยคำสั่งนี้ (หรือให้ car1_parking_auto.launch.py / parking_mode_manager.py
เรียก service พวกนี้อัตโนมัติตอนเข้าโหมด PARKING แทนก็ได้):
  ros2 lifecycle set /velocity_smoother configure
  ros2 lifecycle set /velocity_smoother activate
"""

from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

# ==== แก้ path ให้ตรงกับเครื่องจริงตรงนี้ที่เดียว ====
URDF_PATH = '/home/msxi/ros2_ws/src/tes/urdf/tes.urdf'
SLAM_PARAMS = '/home/msxi/ros2_ws/src/tes/config/slam_params.yaml'
SCAN_FILTER_PARAMS = '/home/msxi/ros2_ws/src/tes/config/scan_filter.yaml'
TWIST_MUX_PARAMS = '/home/msxi/ros2_ws/src/tes/config/twist_mux.yaml'
NAV2_PARAMS = '/home/msxi/ros2_ws/src/tes/config/nav2_params.yaml'
EKF_PARAMS = '/home/msxi/ros2_ws/src/tes/config/ekf.yaml'
RVIZ_CONFIG = '/home/msxi/ros2_ws/src/tes/rviz/car1.rviz'

# ==== ESP32 IP: แก้ตรงนี้ที่เดียวถ้า ESP32 เปลี่ยน IP ====
ESP32_IP = '10.38.184.63'  # TODO: ใส่ IP จริงของ ESP32
ESP32_UDP_PORT = 9999


def generate_launch_description():
    return LaunchDescription([

        # 1) micro-ROS agent
        ExecuteProcess(
            cmd=['ros2', 'run', 'micro_ros_agent', 'micro_ros_agent',
                 'udp4', '--port', '8888'],
            output='screen',
        ),

        # 2) robot_state_publisher
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            arguments=[URDF_PATH],
            output='screen',
        ),

        # 3.05) scan_filter (laser_filters)
        Node(
            package='laser_filters',
            executable='scan_to_scan_filter_chain',
            name='scan_filter',
            parameters=[SCAN_FILTER_PARAMS],
            remappings=[
                ('scan', '/scan'),
                ('scan_filtered', '/scan_filtered'),
            ],
            output='screen',
        ),

        # 3.1) ekf_filter_node (robot_localization)
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[EKF_PARAMS],
        ),

        # 3.2) odom_bridge.py -- /odom_lite -> /odom (ย้ายเข้า core)
        Node(
            package='tes',
            executable='odom_bridge.py',
            name='odom_bridge',
            output='screen',
        ),

        # 3.3) udp_cmd_bridge.py -- /cmd_vel -> UDP -> ESP32 (ย้ายเข้า core)
        Node(
            package='tes',
            executable='udp_cmd_bridge.py',
            name='udp_cmd_bridge',
            output='screen',
            parameters=[{
                'esp32_ip': ESP32_IP,
                'udp_port': ESP32_UDP_PORT,
                'cmd_topic': '/cmd_vel',
                'msg_type': 'twist',
                'send_hz': 30.0,
            }],
        ),

        # 4) joy_node -- อยู่ใน core เสมอ (ดูคำอธิบายด้านบน)
        Node(
            package='joy',
            executable='joy_node',
            output='screen',
        ),

        # 7) Twist mux -- อยู่ใน core เสมอ
        Node(
            package='twist_mux',
            executable='twist_mux',
            name='twist_mux',
            parameters=[TWIST_MUX_PARAMS],
            remappings=[('/cmd_vel_out', '/cmd_vel')],
            output='screen',
        ),

        # 8) slam_toolbox
        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[SLAM_PARAMS],
        ),

        # 8.1) lifecycle_manager สำหรับ slam_toolbox
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_slam',
            output='screen',
            parameters=[{
                'autostart': True,
                'node_names': ['slam_toolbox'],
                'bond_timeout': 0.0,
            }],
        ),

        # 9) Nav2 stack (ไม่มี smoother_server แล้ว -- ดูเหตุผลด้านบน)
        Node(
            package='nav2_controller',
            executable='controller_server',
            name='controller_server',
            output='screen',
            parameters=[NAV2_PARAMS],
            remappings=[('cmd_vel', 'cmd_vel_nav')],
        ),
        Node(
            package='nav2_planner',
            executable='planner_server',
            name='planner_server',
            output='screen',
            parameters=[NAV2_PARAMS],
        ),
        Node(
            package='nav2_behaviors',
            executable='behavior_server',
            name='behavior_server',
            output='screen',
            parameters=[NAV2_PARAMS],
            # *** เพิ่มบรรทัดนี้ -- กัน cmd_vel ชนกับ twist_mux (ดูคำอธิบายด้านบน) ***
            remappings=[('cmd_vel', 'cmd_vel_recovery')],
        ),
        Node(
            package='nav2_bt_navigator',
            executable='bt_navigator',
            name='bt_navigator',
            output='screen',
            parameters=[NAV2_PARAMS],
        ),

        # 9.1) lifecycle_manager สำหรับ Nav2 (ไม่รวม velocity_smoother อีกต่อไป
        # -- แยกไปมี lifecycle_manager ของตัวเองด้านล่าง เพื่อไม่ให้ autostart
        # ไปด้วยกัน ดูคำอธิบายที่หัวไฟล์)
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_navigation',
            output='screen',
            parameters=[{
                'autostart': True,
                'node_names': [
                    'controller_server',
                    'planner_server',
                    'behavior_server',
                    'bt_navigator',
                ],
            }],
        ),

        # 9.5) velocity_smoother -- *** ไม่ autostart แล้ว ดูคำอธิบายที่หัวไฟล์ ***
        Node(
            package='nav2_velocity_smoother',
            executable='velocity_smoother',
            name='velocity_smoother',
            output='screen',
            parameters=[NAV2_PARAMS],
            remappings=[
                ('cmd_vel', 'cmd_vel_nav'),
                ('cmd_vel_smoothed', 'cmd_vel_auto'),
            ],
        ),

        # 9.6) lifecycle_manager แยกเฉพาะ velocity_smoother -- autostart=False
        # โดยตั้งใจ ต้อง activate เองตอนต้องการใช้จริง (ดูคำสั่งที่หัวไฟล์)
        Node(
            package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
            name='lifecycle_manager_smoother',
            output='screen',
            parameters=[{
                'autostart': False,
                'node_names': ['velocity_smoother'],
            }],
        ),

        # 10) RViz2
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', RVIZ_CONFIG],
            output='screen',
        ),
    ])
