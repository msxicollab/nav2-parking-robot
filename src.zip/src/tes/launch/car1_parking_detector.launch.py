#!/usr/bin/env python3
"""
car1_parking_detector.launch.py
==================================
เปิดเมื่อ: ต้องการให้ระบบเริ่มสแกนหาช่องจอด (หลังขับผ่านช่องจอดที่ต้องการแล้ว)
ปิดเมื่อ: เห็นเป้าหมาย/เส้นทาง (/plan) ขึ้นใน RViz แล้วพอใจกับช่องที่เจอ
          (Ctrl+C ที่ terminal นี้)

มีแค่ parking_spot_detector.py ตัวเดียว -> publish /parking/target_pose
ให้ parking_maneuver.py (อยู่คนละไฟล์ car1_parking_auto.launch.py) ใช้ต่อ

หมายเหตุ: ปิดไฟล์นี้แล้ว target_pose ล่าสุดที่เคย publish ไว้จะยังอยู่ที่
parking_maneuver.py จำไว้ใช้ได้ (ตราบใดที่ยังไม่เกิน target_max_age_sec ที่
ตั้งไว้ใน car1_parking_auto.launch.py) ไม่ต้องเปิดไฟล์นี้ค้างไว้ตลอด

ต้องรัน car1_core.launch.py (terminal อื่น) อยู่ก่อนแล้วเสมอ

วิธีรัน:
  source /opt/ros/jazzy/setup.bash
  source ~/ros2_ws/install/setup.bash
  ros2 launch /home/msxi/ros2_ws/src/tes/launch/car1_parking_detector.launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        Node(
            package='tes',
            executable='parking_spot_detector.py',
            output='screen',
        ),
    ])
