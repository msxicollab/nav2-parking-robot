#!/usr/bin/env python3
"""
car1_parking_auto.launch.py
==============================
เปิดเมื่อ: พร้อมสั่งจอดอัตโนมัติแล้ว (มี /parking/target_pose สดจาก
          parking_spot_detector.py แล้ว ไม่ว่า terminal ของมันจะยังเปิดอยู่
          หรือปิดไปแล้วก็ได้ ตราบใดที่ target ยังไม่หมดอายุ)

มี:
  - parking_mode_manager.py  -> ฟังปุ่ม B จาก /joy (ซึ่งมาจาก joy_node ใน
    car1_core.launch.py ที่เปิดค้างไว้ตลอด) สลับโหมด MANUAL <-> AUTO_PARK
  - parking_maneuver.py      -> เรียก Nav2 action navigate_to_pose ไปยัง
    /parking/target_pose ที่ detector หามาให้

*** สำคัญ: ไฟล์นี้ทำงานได้ก็ต่อเมื่อ joy_node (ใน car1_core.launch.py) ยังรัน
อยู่เท่านั้น เพราะปุ่ม B มาจาก /joy topic ถ้า joy_node ถูกปิดไปด้วยจะกด B
สั่งเริ่มจอดไม่ได้เลย ***

ต้องรัน car1_core.launch.py (terminal อื่น) อยู่ก่อนแล้วเสมอ

วิธีรัน:
  source /opt/ros/jazzy/setup.bash
  source ~/ros2_ws/install/setup.bash
  ros2 launch /home/msxi/ros2_ws/src/tes/launch/car1_parking_auto.launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        Node(
            package='tes',
            executable='parking_mode_manager.py',
            output='screen',
        ),

        Node(
            package='tes',
            executable='parking_maneuver.py',
            output='screen',
            parameters=[{
                'target_max_age_sec': 8.0,
                'max_target_distance': 6.0,
                'final_reverse_enable': False,
                'lidar_to_rear_m': 0.35,
                'target_gap_m': 0.22,
                'brake_margin_m': 0.02,
                # --- จัดตัวให้ขนานกำแพงหลัง Nav2 ถึงเป้า ---
                'align_enable': True,
                'align_tolerance_deg': 3.0,
                'align_leg_distance_m': 0.08,
                'align_max_legs': 6,
                'lidar_to_front_m': 0.25,   # *** วัดจริง: LiDAR -> กันชนหน้า ***
                'final_reverse_heading_hold': True,
            }],
        ),
    ])
