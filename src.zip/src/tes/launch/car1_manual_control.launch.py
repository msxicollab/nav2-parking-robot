#!/usr/bin/env python3
"""
car1_manual_control.launch.py
================================
เปิดเมื่อ: ต้องการขับรถด้วยจอยด้วยมือ (เช่น ขับไปยัง waypoint / ผ่านช่องจอด)
ปิดเมื่อ: ถึง waypoint แล้ว ไม่ต้องการบังคับมือต่อ (Ctrl+C ที่ terminal นี้)

มีแค่ joy_to_cmd_vel.py ตัวเดียว (แปลงแกน joystick -> /cmd_vel_manual)
*** ไม่มี joy_node ในไฟล์นี้ *** เพราะ joy_node ต้องอยู่ใน car1_core.launch.py
ตลอดเวลา (parking_mode_manager.py ต้องใช้ /joy ฟังปุ่ม B ต่อ แม้ปิดไฟล์นี้
ไปแล้วก็ตาม)

ต้องรัน car1_core.launch.py (terminal อื่น) อยู่ก่อนแล้วเสมอ

วิธีรัน:
  source /opt/ros/jazzy/setup.bash
  source ~/ros2_ws/install/setup.bash
  ros2 launch /home/msxi/ros2_ws/src/tes/launch/car1_manual_control.launch.py
"""

from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        Node(
            package='tes',
            executable='joy_to_cmd_vel.py',
            output='screen',
        ),
    ])
